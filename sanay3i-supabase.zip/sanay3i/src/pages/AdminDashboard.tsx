/*
  Sanay3i — AdminDashboard
  - Protected by real Supabase Auth (see AdminLogin.tsx / lib/supabase.ts)
  - Shows bookings, pro applications, and approved pro accounts —
    all admin-only rows, unlocked by the signed-in session's token.
*/

import { useEffect, useMemo, useState } from "react";
import { useLocation } from "wouter";
import { format } from "date-fns";
import { MessageCircle, Users, ClipboardList, LayoutDashboard, Printer } from "lucide-react";

import SiteLayout from "@/components/SiteLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import { adminSignOut, isAdminSessionValid, sbInsert, sbSelect, sbUpdate } from "@/lib/supabase";

type BookingStatus = "new" | "contacted" | "closed";

type BookingRating = {
  stars: number; // 1-5
  comment?: string;
  ratedAt: string; // ISO
};

type BookingRequest = {
  id: string;
  trackingCode?: string;
  createdAt: string;
  customerName: string;
  customerPhone: string;
  service: string;
  city: string;
  dateISO: string;
  slot: string;
  payment: string;
  notes: string;
  status: any;
  assignedProId?: string;
  assignedProSnapshot?: null | { id: string; name: string; phone: string; trade: string; city?: string };
  rating?: BookingRating;
  invoiceMaterialsCost?: number;
  invoiceLaborCost?: number;
  invoiceTransportCost?: number;
  invoiceDiscount?: number;
  invoiceNotes?: string;
  invoiceStatus?: string;
};

type ProApplication = {
  id: string;
  createdAt: string;
  status: "new" | "approved" | "rejected";
  name: string;
  phone: string;
  trade: string;
  city: string;
  experienceYears: string;
  bio: string;
  skills?: string[];

  nationalId?: string;
  idFrontDataUrl?: string;
  idBackDataUrl?: string;
  selfieDataUrl?: string;
};

type ProAccount = {
  id: string;
  applicationId?: string;
  name: string;
  phone: string;
  trade: string;
  city: string;
  accessCode: string;
  skills?: string[];
  createdAt: string;
};

function makeProAccessCode() {
  return `PRO-${Math.floor(1000 + Math.random() * 9000)}`;
}

function fromBookingRow(row: any): BookingRequest {
  return {
    id: row.id,
    trackingCode: row.tracking_code,
    createdAt: row.created_at,
    customerName: row.customer_name,
    customerPhone: row.customer_phone,
    service: row.service,
    city: row.city,
    dateISO: row.date_iso,
    slot: row.slot,
    payment: row.payment,
    notes: row.notes,
    status: row.status,
    assignedProId: row.assigned_pro_id || "",
    rating: undefined,
    invoiceMaterialsCost: row.invoice_materials_cost != null ? Number(row.invoice_materials_cost) : undefined,
    invoiceLaborCost: row.invoice_labor_cost != null ? Number(row.invoice_labor_cost) : undefined,
    invoiceTransportCost: row.invoice_transport_cost != null ? Number(row.invoice_transport_cost) : undefined,
    invoiceDiscount: row.invoice_discount != null ? Number(row.invoice_discount) : 0,
    invoiceNotes: row.invoice_notes || undefined,
    invoiceStatus: row.invoice_status || undefined,
  };
}

function fromApplicationRow(row: any): ProApplication {
  return {
    id: row.id,
    createdAt: row.created_at,
    status: row.status,
    name: row.name,
    phone: row.phone,
    trade: row.trade,
    city: row.city,
    experienceYears: row.experience_years,
    bio: row.bio,
    skills: row.skills || [],
    nationalId: row.national_id,
    idFrontDataUrl: row.id_front_data_url,
    idBackDataUrl: row.id_back_data_url,
    selfieDataUrl: row.selfie_data_url,
  };
}

function fromProRow(row: any): ProAccount {
  return {
    id: row.id,
    applicationId: row.application_id,
    name: row.name,
    phone: row.phone,
    trade: row.trade,
    city: row.city,
    accessCode: row.access_code,
    skills: row.skills || [],
    createdAt: row.created_at,
  };
}

function bookingBadge(s: string) {
  if (s === "new") return <Badge className="bg-accent text-accent-foreground">جديد</Badge>;
  if (s === "contacted") return <Badge className="bg-blue-600 text-white">جاري التنفيذ</Badge>;
  if (s === "work_completed") return <Badge className="bg-green-600 text-white">تم التنفيذ (مراجعة)</Badge>;
  if (s === "closed") return <Badge variant="secondary">مقفول</Badge>;
  return <Badge variant="outline">{s}</Badge>;
}

function proBadge(s: ProApplication["status"]) {
  if (s === "new") return <Badge className="bg-accent text-accent-foreground">جديد</Badge>;
  if (s === "approved") return <Badge className="bg-primary text-primary-foreground">مقبول</Badge>;
  return <Badge variant="secondary">مرفوض</Badge>;
}

export default function AdminDashboard() {
  const [, setLocation] = useLocation();

  // "bookings" or "pros"
  const [activeTab, setActiveTab] = useState("bookings");
  const [discountDrafts, setDiscountDrafts] = useState<Record<string, string>>({});
  const [bookings, setBookings] = useState<BookingRequest[]>([]);
  const [pros, setPros] = useState<ProApplication[]>([]);
  const [proAccounts, setProAccounts] = useState<ProAccount[]>([]);

  async function loadAll() {
    try {
      const [bookingRows, appRows, proRows] = await Promise.all([
        sbSelect<any>("bookings", { select: "*,ratings(stars,comment,rated_at)" }),
        sbSelect<any>("pro_applications", { select: "*" }),
        sbSelect<any>("pros", { select: "*" }),
      ]);
      setBookings(
        bookingRows.map((row) => {
          const b = fromBookingRow(row);
          const ratingRow = Array.isArray(row.ratings) ? row.ratings[0] : row.ratings;
          if (ratingRow) {
            b.rating = { stars: ratingRow.stars, comment: ratingRow.comment, ratedAt: ratingRow.rated_at };
          }
          return b;
        })
      );
      setPros(appRows.map(fromApplicationRow));
      setProAccounts(proRows.map(fromProRow));
    } catch (err) {
      console.error(err);
      toast.error("حصلت مشكلة في تحميل البيانات");
    }
  }

  useEffect(() => {
    const authed = isAdminSessionValid();
    if (!authed) {
      setLocation("/admin");
      return;
    }
    void loadAll();
  }, [setLocation]);

  const bookingCounts = useMemo(() => {
    const n = { all: bookings.length, new: 0, contacted: 0, closed: 0, rated: 0, avg: 0 } as any;
    let sum = 0;
    let cnt = 0;
    bookings.forEach((b) => {
      if (b.status === "new") n.new += 1;
      else if (b.status === "contacted") n.contacted += 1;
      else n.closed += 1;

      const stars = (b as any).rating?.stars;
      if (typeof stars === "number") {
        n.rated += 1;
        sum += stars;
        cnt += 1;
      }
    });
    n.avg = cnt ? Math.round((sum / cnt) * 10) / 10 : 0;
    return n;
  }, [bookings]);

  const proCounts = useMemo(() => {
    const n = { all: pros.length, new: 0, approved: 0, rejected: 0 };
    pros.forEach((p) => {
      if (p.status === "new") n.new += 1;
      else if (p.status === "approved") n.approved += 1;
      else n.rejected += 1;
    });
    return n;
  }, [pros]);

  function refresh() {
    void loadAll();
    toast.message("تم تحديث البيانات");
  }

  async function updateBookingStatus(id: string, status: BookingStatus) {
    try {
      await sbUpdate("bookings", { id: `eq.${id}` }, { status });
      setBookings((prev) => prev.map((x) => (x.id === id ? { ...x, status } : x)));
    } catch (err) {
      console.error(err);
      toast.error("حصلت مشكلة في تحديث الحالة");
    }
  }

  async function approveInvoice(id: string) {
    const discount = Number(discountDrafts[id]) || 0;
    try {
      await sbUpdate(
        "bookings",
        { id: `eq.${id}` },
        { invoice_discount: discount, invoice_status: "approved", invoice_approved_at: new Date().toISOString() }
      );
      setBookings((prev) =>
        prev.map((x) => (x.id === id ? { ...x, invoiceDiscount: discount, invoiceStatus: "approved" } : x))
      );
      toast.success("تم اعتماد الفاتورة — بقت متاحة للعميل");
    } catch (err) {
      console.error(err);
      toast.error("حصلت مشكلة في اعتماد الفاتورة");
    }
  }

  async function updateProStatus(id: string, status: ProApplication["status"]) {
    try {
      await sbUpdate("pro_applications", { id: `eq.${id}` }, { status });
      setPros((prev) => prev.map((x) => (x.id === id ? { ...x, status } : x)));
    } catch (err) {
      console.error(err);
      toast.error("حصلت مشكلة في تحديث الحالة");
    }
  }

  async function approveProAndCreateAccount(p: ProApplication) {
    // 1) mark application approved
    await updateProStatus(p.id, "approved");

    // 2) create account if not exists
    const exists = proAccounts.some((x) => x.applicationId === p.id);
    if (exists) return;
    try {
      const row = await sbInsert<any>("pros", {
        application_id: p.id,
        name: p.name,
        phone: p.phone,
        trade: p.trade,
        city: p.city,
        access_code: makeProAccessCode(),
        skills: p.skills || [],
      });
      const acc = fromProRow(row);
      setProAccounts((prev) => [acc, ...prev]);
      toast.success("تم قبول الصنايعي", { description: `كود الدخول: ${acc.accessCode}` });
    } catch (err) {
      console.error(err);
      toast.error("حصلت مشكلة في إنشاء حساب الصنايعي");
    }
  }

  async function assignProToBooking(bookingId: string, proId: string) {
    const pro = proAccounts.find((x) => x.id === proId);
    if (!pro) return;

    try {
      await sbUpdate("bookings", { id: `eq.${bookingId}` }, { assigned_pro_id: pro.id, status: "assigned" });
      setBookings((prev) =>
        prev.map((b) => (b.id === bookingId ? { ...b, status: "assigned", assignedProId: pro.id } : b))
      );
      toast.message("تم تعيين الصنايعي للطلب");
    } catch (err) {
      console.error(err);
      toast.error("حصلت مشكلة في تعيين الصنايعي");
    }
  }

  return (
    <SiteLayout>
      <section className="container-sanay3i section-sanay3i">
        {/* Header Section */}
        <div className="flex flex-col gap-4 md:flex-row md:items-end md:justify-between mb-8">
          <div>
            <h1 className="font-display text-3xl font-bold md:text-4xl flex items-center gap-3">
              <LayoutDashboard className="h-8 w-8 text-primary" />
              لوحة تحكم Sanay3i
            </h1>
            <p className="mt-2 text-muted-foreground leading-7">
              إدارة الطلبات والصنايعية.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <Button variant="outline" onClick={refresh}>
              تحديث البيانات
            </Button>
            <Button
              variant="destructive"
              onClick={async () => {
                await adminSignOut();
                toast.message("تم تسجيل الخروج");
                setLocation("/admin");
              }}
            >
              خروج
            </Button>
          </div>
        </div>

        {/* Top Stats Overview */}
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4 mb-10">
          <Card className="card-elevated border-l-4 border-l-primary bg-card/60">
            <CardContent className="p-5">
              <div className="text-sm text-muted-foreground">طلبات الحجز (الكل)</div>
              <div className="mt-1 text-3xl font-bold">{bookingCounts.all}</div>
              <div className="mt-2 text-xs text-muted-foreground">
                <span className="text-primary font-semibold">{bookingCounts.new}</span> جديد
              </div>
            </CardContent>
          </Card>
          <Card className="card-elevated border-l-4 border-l-secondary bg-card/60">
            <CardContent className="p-5">
              <div className="text-sm text-muted-foreground">طلبات الانضمام</div>
              <div className="mt-1 text-3xl font-bold">{proCounts.all}</div>
              <div className="mt-2 text-xs text-muted-foreground">
                <span className="text-primary font-semibold">{proCounts.new}</span> قيد الانتظار
              </div>
            </CardContent>
          </Card>
          <Card className="card-elevated border-l-4 border-l-green-500 bg-card/60">
            <CardContent className="p-5">
              <div className="text-sm text-muted-foreground">الصنايعية المقبولين</div>
              <div className="mt-1 text-3xl font-bold">{proCounts.approved}</div>
              <div className="mt-2 text-xs text-muted-foreground">
                جاهزين للعمل
              </div>
            </CardContent>
          </Card>
          <Card className="card-elevated border-l-4 border-l-orange-500 bg-card/60">
            <CardContent className="p-5">
              <div className="text-sm text-muted-foreground">متوسط التقييم</div>
              <div className="mt-1 text-3xl font-bold">{bookingCounts.avg}</div>
              <div className="mt-2 text-xs text-muted-foreground">
                من {bookingCounts.rated} عميل
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Tabs */}
        <Tabs defaultValue="bookings" value={activeTab} onValueChange={setActiveTab} className="w-full">
          <div className="flex items-center justify-between mb-6">
            <TabsList className="bg-secondary/20 p-1 h-auto rounded-xl">
              <TabsTrigger value="bookings" className="rounded-lg px-6 py-2.5 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
                <ClipboardList className="h-4 w-4" />
                طلبات الحجز
              </TabsTrigger>
              <TabsTrigger value="pros" className="rounded-lg px-6 py-2.5 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
                <Users className="h-4 w-4" />
                طلبات الصنايعية
              </TabsTrigger>
            </TabsList>
          </div>

          <TabsContent value="bookings" className="animate-in fade-in-50 slide-in-from-bottom-2 duration-300">
            <div className="flex flex-wrap gap-2 mb-4 text-sm text-muted-foreground bg-secondary/10 p-3 rounded-lg border">
              <span className="font-semibold">ملخص الحالة:</span>
              <Badge variant="outline" className="bg-background">جديد: {bookingCounts.new}</Badge>
              <Badge variant="outline" className="bg-background">تم التواصل: {bookingCounts.contacted}</Badge>
              <Badge variant="outline" className="bg-background">مقفول: {bookingCounts.closed}</Badge>
            </div>

            <div className="grid gap-4">
              {bookings.length ? (
                bookings
                  .slice()
                  .sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1))
                  .map((b) => (
                    <Card key={b.id} className="overflow-hidden card-elevated border hover:border-primary/30 transition-colors">
                      <CardHeader className="pb-3 bg-secondary/5 border-b">
                        <div className="flex flex-wrap items-center justify-between gap-3">
                          <div className="flex items-center gap-3">
                            <Badge variant="outline" className="font-mono text-xs">{b.trackingCode}</Badge>
                            <CardTitle className="text-lg">
                              {b.service} — {b.city}
                            </CardTitle>
                          </div>
                          <div className="flex items-center gap-2">
                            {bookingBadge(b.status)}
                            <div className="text-xs text-muted-foreground">
                              {b.dateISO} ({b.slot})
                            </div>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent className="pt-4 text-sm">
                        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                          {/* Column 1: Customer Info */}
                          <div className="space-y-1">
                            <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">العميل</div>
                            <div className="font-bold text-lg">{b.customerName || "-"}</div>
                            <div className="flex items-center gap-2 mt-1">
                              <div className="text-foreground/80">{b.customerPhone || "-"}</div>
                              {b.customerPhone ? (
                                <a 
                                  href={`https://wa.me/${b.customerPhone.replace(/\D/g, '').startsWith('20') ? b.customerPhone.replace(/\D/g, '') : '20' + b.customerPhone.replace(/\D/g, '')}?text=${encodeURIComponent("مرحبًا، بخصوص طلبك على Sanay3i.")}`} 
                                  target="_blank" 
                                  rel="noreferrer"
                                >
                                  <Button size="icon" variant="ghost" className="h-6 w-6 text-green-600 hover:text-green-700 hover:bg-green-50">
                                    <MessageCircle className="h-4 w-4" />
                                  </Button>
                                </a>
                              ) : null}
                            </div>
                            <div className="text-xs text-muted-foreground mt-1">دفع: {b.payment || "-"}</div>
                          </div>

                          {/* Column 2: Notes & Details */}
                          <div className="space-y-1">
                            <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">تفاصيل</div>
                            {b.notes ? (
                              <div className="bg-secondary/20 p-2 rounded-md text-foreground/90 text-xs leading-relaxed max-h-[100px] overflow-y-auto">
                                {b.notes}
                              </div>
                            ) : (
                              <div className="text-muted-foreground italic text-xs">لا توجد ملاحظات</div>
                            )}
                          </div>

                          {/* Column 3: Actions */}
                          <div className="space-y-3 border-r pr-0 lg:pr-6 border-transparent lg:border-border">
                            <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">الإجراءات</div>
                            <div className="flex flex-wrap gap-2">
                              <Button size="sm" variant={b.status === "new" ? "default" : "outline"} className="h-8" onClick={() => updateBookingStatus(b.id, "new")}>
                                جديد
                              </Button>
                              <Button size="sm" variant={b.status === "contacted" ? "default" : "outline"} className="h-8" onClick={() => updateBookingStatus(b.id, "contacted")}>
                                جاري التنفيذ
                              </Button>
                              <Button size="sm" variant={b.status === "closed" ? "secondary" : "outline"} className="h-8" onClick={() => updateBookingStatus(b.id, "closed")}>
                                إغلاق الطلب
                              </Button>
                            </div>
                            
                            {b.status === "work_completed" && (
                              <div className="mt-3 bg-green-50 border border-green-200 rounded-lg p-3">
                                <div className="text-xs font-bold text-green-700 mb-2">✅ الصنايعي بلغ إنه خلص الشغل</div>
                                <div className="flex flex-col gap-2">
                                  {b.customerPhone ? (
                                    <a 
                                      href={`https://wa.me/${b.customerPhone.replace(/\D/g, '').startsWith('20') ? b.customerPhone.replace(/\D/g, '') : '20' + b.customerPhone.replace(/\D/g, '')}?text=${encodeURIComponent("مساء الخير يا فندم، الصنايعي بلغنا إنه خلص الشغل. حابين نتطمن من حضرتك إن كله تمام؟")}`} 
                                      target="_blank" 
                                      rel="noreferrer"
                                    >
                                      <Button size="sm" className="w-full h-8 gap-2 bg-green-600 hover:bg-green-700 text-white">
                                        <MessageCircle className="h-3.5 w-3.5" /> اسأل العميل (واتس)
                                      </Button>
                                    </a>
                                  ) : null}
                                  <Button size="sm" variant="outline" className="w-full h-8 border-green-600 text-green-700 hover:bg-green-50" onClick={() => updateBookingStatus(b.id, "closed")}>
                                    تأكيد وإغلاق الطلب
                                  </Button>
                                </div>
                              </div>
                            )}

                            {/* Invoice review — pro submitted a cost breakdown, waiting for admin approval */}
                            {b.invoiceStatus === "submitted" && (
                              <div className="mt-3 rounded-lg border border-amber-300 bg-amber-50 p-3 space-y-2">
                                <div className="text-xs font-bold text-amber-800">🧾 فاتورة مرسلة من الصنايعي — محتاجة مراجعتك</div>
                                {b.invoiceNotes && (
                                  <div className="text-xs bg-white/70 rounded p-2 text-foreground/80">{b.invoiceNotes}</div>
                                )}
                                <div className="text-xs text-foreground/80 flex flex-wrap gap-x-3">
                                  <span>خامات: {b.invoiceMaterialsCost ?? 0} ج</span>
                                  <span>أجرة: {b.invoiceLaborCost ?? 0} ج</span>
                                  <span>انتقال: {b.invoiceTransportCost ?? 0} ج</span>
                                </div>
                                <div className="flex items-center gap-2">
                                  <label className="text-xs text-muted-foreground shrink-0">خصم (اختياري):</label>
                                  <input
                                    type="number"
                                    className="h-8 w-24 rounded-md border bg-background px-2 text-sm"
                                    placeholder="0"
                                    value={discountDrafts[b.id] || ""}
                                    onChange={(e) => setDiscountDrafts((prev) => ({ ...prev, [b.id]: e.target.value }))}
                                  />
                                </div>
                                <div className="text-xs font-bold">
                                  الإجمالي بعد الخصم:{" "}
                                  {(b.invoiceMaterialsCost ?? 0) + (b.invoiceLaborCost ?? 0) + (b.invoiceTransportCost ?? 0) - (Number(discountDrafts[b.id]) || 0)}{" "}
                                  ج.م
                                </div>
                                <Button size="sm" className="w-full h-8 bg-amber-600 hover:bg-amber-700 text-white" onClick={() => approveInvoice(b.id)}>
                                  اعتماد الفاتورة وإرسالها للعميل
                                </Button>
                              </div>
                            )}

                            {/* Invoice approved — admin can print/share it */}
                            {b.invoiceStatus === "approved" && (
                              <div className="mt-3 rounded-lg border border-green-300 bg-green-50 p-3 space-y-2">
                                <div className="text-xs font-bold text-green-800">✅ الفاتورة معتمدة ومتاحة للعميل</div>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  className="w-full h-8 gap-2 border-green-600 text-green-700 hover:bg-green-100"
                                  onClick={() => window.open(`#/invoice/${b.trackingCode}`, "_blank")}
                                >
                                  <Printer className="h-3.5 w-3.5" /> عرض / طباعة الفاتورة
                                </Button>
                              </div>
                            )}

                            <div className="pt-2">
                              <label className="text-xs text-muted-foreground block mb-1.5">تعيين صنايعي:</label>
                              <select
                                className="h-9 w-full rounded-md border bg-background px-3 text-sm focus:ring-2 focus:ring-primary/20"
                                value={b.assignedProId || ""}
                                onChange={(e) => assignProToBooking(b.id, e.target.value)}
                              >
                                <option value="">— اختر صنايعي —</option>
                                {proAccounts.map((p) => (
                                  <option key={p.id} value={p.id}>
                                    {p.name} ({p.trade})
                                  </option>
                                ))}
                              </select>
                            </div>
                          </div>
                        </div>

                        {/* Rating Section */}
                        {(b as any).rating ? (
                          <div className="mt-4 pt-4 border-t flex items-start gap-3 bg-secondary/10 -mx-6 -mb-6 p-4">
                            <div className="bg-background rounded-full p-1.5 shadow-sm">
                              <span className="font-bold text-lg px-2">{(b as any).rating.stars}</span>
                              <span className="text-xs text-muted-foreground">/5</span>
                            </div>
                            <div>
                              <div className="text-xs font-semibold text-muted-foreground">تقييم العميل</div>
                              <div className="text-sm italic mt-0.5">"{(b as any).rating.comment || 'بدون تعليق'}"</div>
                            </div>
                          </div>
                        ) : null}
                      </CardContent>
                    </Card>
                  ))
              ) : (
                <div className="text-center py-12 bg-secondary/5 rounded-xl border border-dashed">
                  <ClipboardList className="h-12 w-12 text-muted-foreground mx-auto mb-3 opacity-50" />
                  <h3 className="text-lg font-semibold">مفيش طلبات حجز</h3>
                  <p className="text-muted-foreground text-sm mt-1">الطلبات الجديدة هتظهر هنا لما العملاء يحجزوا.</p>
                </div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="pros" className="animate-in fade-in-50 slide-in-from-bottom-2 duration-300">
            <div className="flex flex-wrap gap-2 mb-4 text-sm text-muted-foreground bg-secondary/10 p-3 rounded-lg border">
              <span className="font-semibold">حالة الطلبات:</span>
              <Badge variant="outline" className="bg-background">جديد: {proCounts.new}</Badge>
              <Badge variant="outline" className="bg-background">مقبول: {proCounts.approved}</Badge>
              <Badge variant="outline" className="bg-background">مرفوض: {proCounts.rejected}</Badge>
            </div>

            <div className="grid gap-4">
              {pros.length ? (
                pros
                  .slice()
                  .sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1))
                  .map((p) => (
                    <Card key={p.id} className="overflow-hidden card-elevated border hover:border-primary/30 transition-colors">
                      <CardHeader className="pb-3 bg-secondary/5 border-b">
                        <div className="flex flex-wrap items-center justify-between gap-3">
                          <CardTitle className="text-lg flex items-center gap-2">
                            {p.name || "-"}
                            <Badge variant="outline" className="font-normal text-sm">{p.trade}</Badge>
                          </CardTitle>
                          <div className="flex items-center gap-2">
                            {proBadge(p.status)}
                            <span className="text-xs text-muted-foreground">{format(new Date(p.createdAt), "yyyy-MM-dd")}</span>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent className="pt-4 text-sm">
                        <div className="grid gap-6 md:grid-cols-2">
                          <div className="space-y-4">
                            <div className="grid grid-cols-2 gap-4">
                              <div>
                                <div className="text-xs text-muted-foreground">رقم الموبايل</div>
                                <div className="font-semibold flex items-center gap-2">
                                  {p.phone || "-"}
                                  {p.phone ? (
                                    <a 
                                      href={`https://wa.me/${p.phone.replace(/\D/g, '').startsWith('20') ? p.phone.replace(/\D/g, '') : '20' + p.phone.replace(/\D/g, '')}?text=${encodeURIComponent(
                                        proAccounts.find((x) => x.applicationId === p.id) 
                                          ? `مرحبًا ${p.name.split(" ")[0]}،\n\nتم قبول طلبك للانضمام إلى Sanay3i!\n\n🔹 كود الدخول الخاص بيك: ${proAccounts.find((x) => x.applicationId === p.id)?.accessCode}\n\nتعليمات مهمة:\n1. ادخل على لوحة الصنايعي من الموقع.\n2. استخدم الكود ده لتسجيل الدخول.\n3. هتظهرلك الطلبات القريبة منك عشان تبدأ شغل.\n\nبالتوفيق!`
                                          : "مرحبًا، بخصوص تقديمك في Sanay3i."
                                      )}`} 
                                      target="_blank" 
                                      rel="noreferrer"
                                    >
                                      <Button size="icon" variant="ghost" className="h-6 w-6 text-green-600 hover:text-green-700 hover:bg-green-50">
                                        <MessageCircle className="h-4 w-4" />
                                      </Button>
                                    </a>
                                  ) : null}
                                </div>
                              </div>
                              <div>
                                <div className="text-xs text-muted-foreground">المنطقة</div>
                                <div className="font-semibold">{p.city}</div>
                              </div>
                              <div>
                                <div className="text-xs text-muted-foreground">سنين الخبرة</div>
                                <div className="font-semibold">{p.experienceYears}</div>
                              </div>
                              <div>
                                <div className="text-xs text-muted-foreground">الرقم القومي</div>
                                <div className="font-mono">{p.nationalId || "-"}</div>
                              </div>
                            </div>

                            {p.bio && (
                              <div className="bg-secondary/20 p-3 rounded-lg text-xs leading-relaxed">
                                <span className="font-bold block mb-1">نبذة:</span>
                                {p.bio}
                              </div>
                            )}
                          </div>

                          <div className="space-y-4 border-t pt-4 md:border-t-0 md:pt-0 md:border-r md:pr-4">
                            <div>
                              <div className="text-xs font-semibold text-muted-foreground mb-2">المستندات والصور</div>
                              <div className="flex flex-wrap gap-3">
                                {p.selfieDataUrl ? (
                                  <a href={p.selfieDataUrl} target="_blank" rel="noreferrer" className="group block">
                                    <img src={p.selfieDataUrl} alt="Selfie" className="h-16 w-16 rounded-lg border object-cover shadow-sm transition-transform group-hover:scale-105" />
                                    <span className="text-[10px] text-center block mt-1 text-muted-foreground">صورة شخصية</span>
                                  </a>
                                ) : null}
                                {p.idFrontDataUrl ? (
                                  <a href={p.idFrontDataUrl} target="_blank" rel="noreferrer" className="group block">
                                    <img src={p.idFrontDataUrl} alt="ID Front" className="h-16 w-24 rounded-lg border object-cover shadow-sm transition-transform group-hover:scale-105" />
                                    <span className="text-[10px] text-center block mt-1 text-muted-foreground">بطاقة (أمام)</span>
                                  </a>
                                ) : null}
                                {p.idBackDataUrl ? (
                                  <a href={p.idBackDataUrl} target="_blank" rel="noreferrer" className="group block">
                                    <img src={p.idBackDataUrl} alt="ID Back" className="h-16 w-24 rounded-lg border object-cover shadow-sm transition-transform group-hover:scale-105" />
                                    <span className="text-[10px] text-center block mt-1 text-muted-foreground">بطاقة (خلف)</span>
                                  </a>
                                ) : null}
                                {!p.selfieDataUrl && !p.idFrontDataUrl && !p.idBackDataUrl && (
                                  <div className="text-sm text-muted-foreground italic py-2">لا توجد صور مرفوعة</div>
                                )}
                              </div>
                            </div>

                            <div className="bg-card border rounded-xl p-3 shadow-sm">
                              <div className="text-xs font-semibold mb-2">إجراءات الإدارة</div>
                              <div className="flex flex-wrap gap-2 mb-3">
                                <Button size="sm" variant={p.status === "new" ? "default" : "outline"} onClick={() => updateProStatus(p.id, "new")} className="h-8 text-xs">
                                  قيد الانتظار
                                </Button>
                                <Button size="sm" onClick={() => approveProAndCreateAccount(p)} className="h-8 text-xs bg-green-600 hover:bg-green-700 text-white">
                                  قبول + كود
                                </Button>
                                <Button size="sm" variant="destructive" onClick={() => updateProStatus(p.id, "rejected")} className="h-8 text-xs">
                                  رفض
                                </Button>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  className="h-8 text-xs gap-1"
                                  onClick={() => window.open(`#/admin/print/${p.id}`, "_blank")}
                                >
                                  <Printer className="h-3.5 w-3.5" />
                                  طباعة الاستمارة
                                </Button>
                              </div>
                              
                              {proAccounts.find((x) => x.applicationId === p.id) && (
                                <div className="bg-primary/5 border border-primary/20 rounded-lg p-2 text-center">
                                  <div className="text-[10px] text-muted-foreground mb-1">كود الدخول المولد</div>
                                  <div className="font-mono font-bold text-lg text-primary tracking-wider select-all">
                                    {proAccounts.find((x) => x.applicationId === p.id)?.accessCode}
                                  </div>
                                </div>
                              )}
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))
              ) : (
                <div className="text-center py-12 bg-secondary/5 rounded-xl border border-dashed">
                  <Users className="h-12 w-12 text-muted-foreground mx-auto mb-3 opacity-50" />
                  <h3 className="text-lg font-semibold">مفيش طلبات صنايعية</h3>
                  <p className="text-muted-foreground text-sm mt-1">الطلبات الجديدة للانضمام هتظهر هنا.</p>
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </section>
    </SiteLayout>
  );
}
