/*
  Sanay3i — ProDashboard
  - Shows bookings assigned to this pro via the pro_dashboard() RPC
*/

import { useEffect, useMemo, useState } from "react";
import { useLocation } from "wouter";
import { format } from "date-fns";

import SiteLayout from "@/components/SiteLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { MessageCircle, MapPin, Calendar, Clock, Navigation, CheckCircle, Briefcase, Star, User, Receipt } from "lucide-react";
import { Separator } from "@/components/ui/separator";
import { toast } from "sonner";
import { sbRpc } from "@/lib/supabase";

type BookingRating = {
  stars: number; // 1-5
  comment?: string;
  ratedAt: string; // ISO
};

type BookingRequest = {
  id: string;
  trackingCode?: string;
  createdAt: string;
  customerName: string;
  customerPhone: string;
  service: string;
  city: string;
  dateISO: string;
  slot: string;
  payment: string;
  notes: string;
  address?: string;
  locationUrl?: string;
  status: string;
  assignedProId?: string;
  rating?: BookingRating;
  invoiceMaterialsCost?: number;
  invoiceLaborCost?: number;
  invoiceTransportCost?: number;
  invoiceNotes?: string;
  invoiceStatus?: string;
};

type ProAccount = {
  id: string;
  name: string;
  phone: string;
  trade: string;
  city: string;
  skills?: string[];
};

function fromRow(row: any): BookingRequest {
  return {
    id: row.id,
    trackingCode: row.tracking_code,
    createdAt: row.created_at,
    customerName: row.customer_name,
    customerPhone: row.customer_phone,
    service: row.service,
    city: row.city,
    dateISO: row.date_iso,
    slot: row.slot,
    payment: row.payment,
    notes: row.notes,
    address: row.address,
    locationUrl: row.location_url,
    status: row.status,
    rating:
      typeof row.rating_stars === "number"
        ? { stars: row.rating_stars, comment: row.rating_comment, ratedAt: row.rating_rated_at }
        : undefined,
    invoiceMaterialsCost: row.invoice_materials_cost != null ? Number(row.invoice_materials_cost) : undefined,
    invoiceLaborCost: row.invoice_labor_cost != null ? Number(row.invoice_labor_cost) : undefined,
    invoiceTransportCost: row.invoice_transport_cost != null ? Number(row.invoice_transport_cost) : undefined,
    invoiceNotes: row.invoice_notes || undefined,
    invoiceStatus: row.invoice_status || undefined,
  };
}

function statusBadge(s: string) {
  if (s === "assigned") return <Badge className="bg-primary text-primary-foreground">متعيّن عليك</Badge>;
  if (s === "contacted") return <Badge className="bg-blue-600 text-white hover:bg-blue-700">جاري التنفيذ</Badge>;
  if (s === "work_completed") return <Badge className="bg-green-600 text-white hover:bg-green-700">تم التنفيذ (انتظار المراجعة)</Badge>;
  if (s === "closed") return <Badge variant="secondary">مقفول (مكتمل)</Badge>;
  return <Badge className="bg-accent text-accent-foreground">جديد</Badge>;
}

export default function ProDashboard() {
  const [, setLocation] = useLocation();

  const [me, setMe] = useState<ProAccount | null>(null);
  const [requests, setRequests] = useState<BookingRequest[]>([]);

  const [invoiceFor, setInvoiceFor] = useState<BookingRequest | null>(null);
  const [materialsCost, setMaterialsCost] = useState("");
  const [laborCost, setLaborCost] = useState("");
  const [transportCost, setTransportCost] = useState("");
  const [invoiceNotes, setInvoiceNotes] = useState("");
  const [submittingInvoice, setSubmittingInvoice] = useState(false);

  async function loadData(myId: string) {
    try {
      const meRaw = localStorage.getItem("sanay3i_pro_me");
      setMe(meRaw ? JSON.parse(meRaw) : null);

      const bookingRows = await sbRpc<any[]>("pro_dashboard", { p_pro_id: myId });
      setRequests((bookingRows || []).map(fromRow));
    } catch (err) {
      console.error(err);
      toast.error("حصلت مشكلة في تحميل البيانات");
    }
  }

  useEffect(() => {
    const authed = localStorage.getItem("sanay3i_pro_authed") === "1";
    const myId = localStorage.getItem("sanay3i_pro_authed_id") || "";
    if (!authed || !myId) {
      setLocation("/pro/login");
      return;
    }
    void loadData(myId);
  }, [setLocation]);

  const stats = useMemo(() => {
    return {
      total: requests.length,
      active: requests.filter(r => r.status !== "closed").length,
      completed: requests.filter(r => r.status === "closed").length,
      avgRating: requests.filter(r => r.rating).length 
        ? (requests.reduce((acc, r) => acc + (r.rating?.stars || 0), 0) / requests.filter(r => r.rating).length).toFixed(1)
        : "0"
    };
  }, [requests]);

  function refresh() {
    const myId = localStorage.getItem("sanay3i_pro_authed_id") || "";
    if (!myId) return;
    void loadData(myId);
    toast.message("تم التحديث");
  }

  function logout() {
    localStorage.removeItem("sanay3i_pro_authed");
    localStorage.removeItem("sanay3i_pro_authed_id");
    localStorage.removeItem("sanay3i_pro_me");
    toast.message("تم تسجيل الخروج");
    setLocation("/pro/login");
  }

  async function updateStatus(id: string, newStatus: string) {
    const myId = localStorage.getItem("sanay3i_pro_authed_id") || "";
    try {
      await sbRpc("pro_update_booking_status", { p_pro_id: myId, p_booking_id: id, p_status: newStatus });
    } catch (err) {
      console.error(err);
      toast.error("حصلت مشكلة في تحديث الحالة");
      return;
    }
    refresh();
    if (newStatus === "work_completed") {
      toast.success("عاش يا وحش! تم إبلاغ الإدارة.");
    } else {
      toast.message("تم تحديث الحالة");
    }
  }

  async function submitInvoice() {
    if (!invoiceFor) return;
    const myId = localStorage.getItem("sanay3i_pro_authed_id") || "";
    const materials = Number(materialsCost) || 0;
    const labor = Number(laborCost) || 0;
    const transport = Number(transportCost) || 0;
    if (!labor && !materials) {
      toast.error("اكتب على الأقل قيمة الخامات أو الأجرة");
      return;
    }
    setSubmittingInvoice(true);
    try {
      await sbRpc("pro_submit_invoice", {
        p_pro_id: myId,
        p_booking_id: invoiceFor.id,
        p_materials_cost: materials,
        p_labor_cost: labor,
        p_transport_cost: transport,
        p_notes: invoiceNotes,
      });
      toast.success("تم إرسال الفاتورة للإدارة للمراجعة");
      setInvoiceFor(null);
      setMaterialsCost("");
      setLaborCost("");
      setTransportCost("");
      setInvoiceNotes("");
      refresh();
    } catch (err) {
      console.error(err);
      toast.error("حصلت مشكلة في إرسال الفاتورة");
    } finally {
      setSubmittingInvoice(false);
    }
  }

  return (
    <SiteLayout>
      <section className="container-sanay3i section-sanay3i">
        <div className="flex flex-col gap-4 md:flex-row md:items-end md:justify-between mb-8">
          <div>
            <h1 className="font-display text-3xl font-bold md:text-4xl flex items-center gap-3">
              <Briefcase className="h-8 w-8 text-primary" />
              لوحة الصنايعي
            </h1>
            <p className="mt-2 text-muted-foreground leading-7">أهلاً يا أسطى {me?.name?.split(' ')[0]}، دي شغلاتك النهاردة.</p>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button variant="outline" onClick={refresh}>
              تحديث
            </Button>
            <Button variant="destructive" onClick={logout}>
              خروج
            </Button>
          </div>
        </div>

        {/* Stats Overview */}
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4 mb-8">
          <Card className="card-elevated border-l-4 border-l-primary bg-card/60">
            <CardContent className="p-5 flex items-center justify-between">
              <div>
                <div className="text-sm text-muted-foreground">شغل نشط</div>
                <div className="mt-1 text-3xl font-bold">{stats.active}</div>
              </div>
              <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center text-primary">
                <Briefcase className="h-5 w-5" />
              </div>
            </CardContent>
          </Card>
          
          <Card className="card-elevated border-l-4 border-l-green-500 bg-card/60">
            <CardContent className="p-5 flex items-center justify-between">
              <div>
                <div className="text-sm text-muted-foreground">شغل مكتمل</div>
                <div className="mt-1 text-3xl font-bold">{stats.completed}</div>
              </div>
              <div className="h-10 w-10 rounded-full bg-green-500/10 flex items-center justify-center text-green-600">
                <CheckCircle className="h-5 w-5" />
              </div>
            </CardContent>
          </Card>

          <Card className="card-elevated border-l-4 border-l-orange-500 bg-card/60">
            <CardContent className="p-5 flex items-center justify-between">
              <div>
                <div className="text-sm text-muted-foreground">تقييمك</div>
                <div className="mt-1 text-3xl font-bold">{stats.avgRating}</div>
              </div>
              <div className="h-10 w-10 rounded-full bg-orange-500/10 flex items-center justify-center text-orange-600">
                <Star className="h-5 w-5" />
              </div>
            </CardContent>
          </Card>

          <Card className="card-elevated border-l-4 border-l-secondary bg-card/60">
            <CardContent className="p-5 flex items-center justify-between">
              <div className="overflow-hidden">
                <div className="text-sm text-muted-foreground">حسابك</div>
                <div className="mt-1 font-bold truncate">{me ? me.name : "-"}</div>
                <div className="text-xs text-muted-foreground truncate">{me ? me.trade : ""}</div>
              </div>
              <div className="h-10 w-10 rounded-full bg-secondary/20 flex items-center justify-center text-foreground">
                <User className="h-5 w-5" />
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <h2 className="font-display text-xl font-bold">الطلبات المسندة إليك</h2>
          
          {requests.length ? (
            <div className="grid gap-6">
              {requests
                .slice()
                .sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1))
                .map((r) => (
                  <Card key={r.id} className="overflow-hidden card-elevated border hover:border-primary/30 transition-colors">
                    <CardHeader className="pb-3 bg-secondary/5 border-b">
                      <div className="flex flex-wrap items-center justify-between gap-3">
                        <div className="flex items-center gap-3">
                          <Badge variant="outline" className="font-mono text-xs">{r.trackingCode}</Badge>
                          <CardTitle className="text-lg">
                            {r.service} — {r.city}
                          </CardTitle>
                        </div>
                        <div className="flex items-center gap-2">
                          {statusBadge(r.status)}
                          <div className="text-xs text-muted-foreground">
                            منذ {format(new Date(r.createdAt), "dd/MM/yyyy")}
                          </div>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="pt-5 text-sm">
                      <div className="grid gap-6 md:grid-cols-3">
                        
                        {/* Column 1: Mission Details (Most Important) */}
                        <div className="md:col-span-1 space-y-4">
                          <div className="rounded-xl border-2 border-primary/10 bg-primary/5 p-4 h-full">
                            <div className="text-xs font-bold text-primary uppercase tracking-wider mb-3">تفاصيل المهمة</div>
                            
                            <div className="space-y-3">
                              <div className="flex items-start gap-3">
                                <Calendar className="h-5 w-5 text-primary shrink-0" />
                                <div>
                                  <div className="font-semibold text-foreground">التاريخ</div>
                                  <div className="text-muted-foreground">{r.dateISO}</div>
                                </div>
                              </div>
                              
                              <div className="flex items-start gap-3">
                                <Clock className="h-5 w-5 text-primary shrink-0" />
                                <div>
                                  <div className="font-semibold text-foreground">الوقت</div>
                                  <div className="text-muted-foreground">{r.slot}</div>
                                </div>
                              </div>

                              <div className="flex items-start gap-3">
                                <MapPin className="h-5 w-5 text-primary shrink-0" />
                                <div>
                                  <div className="font-semibold text-foreground">المكان</div>
                                  <div className="text-muted-foreground">{r.city}</div>
                                  {r.address && <div className="text-xs text-muted-foreground mt-1 bg-background/50 p-1.5 rounded">{r.address}</div>}
                                </div>
                              </div>
                            </div>

                            {r.locationUrl && (
                              <a href={r.locationUrl} target="_blank" rel="noreferrer" className="block mt-4">
                                <Button size="sm" className="w-full gap-2 bg-primary text-primary-foreground hover:bg-primary/90 font-bold">
                                  <Navigation className="h-3.5 w-3.5" /> افتح اللوكيشن (GPS)
                                </Button>
                              </a>
                            )}
                          </div>
                        </div>

                        {/* Column 2: Customer & Payment */}
                        <div className="space-y-4">
                          <div>
                            <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">بيانات العميل</div>
                            <div className="font-bold text-lg">{r.customerName || "غير معروف"}</div>
                            <div className="text-sm text-muted-foreground mb-3">{r.customerPhone || "-"}</div>
                            
                            {r.customerPhone ? (
                              <a 
                                href={`https://wa.me/${r.customerPhone.replace(/\D/g, '').startsWith('20') ? r.customerPhone.replace(/\D/g, '') : '20' + r.customerPhone.replace(/\D/g, '')}?text=${encodeURIComponent("مرحبًا، أنا الفني من Sanay3i بخصوص طلبك.")}`} 
                                target="_blank" 
                                rel="noreferrer"
                              >
                                <Button variant="outline" className="w-full gap-2 border-green-200 hover:bg-green-50 hover:text-green-700">
                                  <MessageCircle className="h-4 w-4 text-green-600" /> كلم العميل واتس
                                </Button>
                              </a>
                            ) : null}
                          </div>

                          <Separator />

                          <div>
                            <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-1">طريقة الدفع</div>
                            <div className="font-semibold">{r.payment || "-"}</div>
                          </div>
                        </div>

                        {/* Column 3: Notes & Actions */}
                        <div className="space-y-4 flex flex-col h-full">
                          <div className="flex-1">
                            <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">ملاحظات</div>
                            {r.notes ? (
                              <div className="bg-secondary/20 p-3 rounded-lg text-foreground/90 text-sm leading-relaxed min-h-[80px]">
                                {r.notes}
                              </div>
                            ) : (
                              <div className="text-muted-foreground italic text-sm">لا توجد ملاحظات إضافية</div>
                            )}
                          </div>

                          <div className="pt-2">
                            {r.status === "assigned" && (
                              <Button className="w-full" onClick={() => updateStatus(r.id, "contacted")}>
                                <CheckCircle className="h-4 w-4" />
                                بدأت الشغل / تواصلت
                              </Button>
                            )}
                            
                            {r.status === "contacted" && (
                              <Button
                                className="w-full bg-green-600 hover:bg-green-700 text-white"
                                onClick={() => {
                                  setInvoiceFor(r);
                                  setMaterialsCost("");
                                  setLaborCost("");
                                  setTransportCost("");
                                  setInvoiceNotes("");
                                }}
                              >
                                <CheckCircle className="h-4 w-4" />
                                خلصت الشغل (إبلاغ الإدارة)
                              </Button>
                            )}

                            {r.status === "work_completed" && (
                              <div className="text-center text-xs font-bold text-green-700 bg-green-50 p-3 rounded border border-green-200 space-y-1">
                                <div>الله ينور! الإدارة بتراجع الفاتورة دلوقتي.</div>
                                {r.invoiceStatus === "submitted" && (
                                  <div className="font-normal text-muted-foreground">
                                    خامات: {r.invoiceMaterialsCost ?? 0} ج — أجرة: {r.invoiceLaborCost ?? 0} ج
                                    {r.invoiceTransportCost ? ` — انتقال: ${r.invoiceTransportCost} ج` : ""}
                                  </div>
                                )}
                              </div>
                            )}

                            {r.status === "closed" && (
                              <div className="text-center text-xs text-muted-foreground bg-secondary/10 p-2 rounded">
                                الطلب اتقفل نهائي.
                              </div>
                            )}
                          </div>
                        </div>

                      </div>
                    </CardContent>
                  </Card>
                ))
            }
            </div>
          ) : (
            <div className="text-center py-16 bg-secondary/5 rounded-2xl border border-dashed">
              <div className="bg-background p-4 rounded-full inline-flex mb-4 shadow-sm">
                <Briefcase className="h-8 w-8 text-muted-foreground opacity-50" />
              </div>
              <h3 className="text-lg font-semibold">مفيش شغل حالياً</h3>
              <p className="text-muted-foreground mt-1 max-w-sm mx-auto">
                لما الإدارة تعين لك طلبات جديدة، هتظهر هنا فوراً. خليك متابع!
              </p>
              <Button variant="outline" onClick={refresh} className="mt-6">
                تحديث الصفحة
              </Button>
            </div>
          )}
        </div>
      </section>

      <Dialog open={!!invoiceFor} onOpenChange={(open) => !open && setInvoiceFor(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Receipt className="h-5 w-5 text-primary" />
              تفاصيل الفاتورة — {invoiceFor?.trackingCode}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <p className="text-sm text-muted-foreground">
              اكتب اللي اشتغلته وقيمة الخامات والأجرة، والإدارة هتراجعها وتبعتها للعميل كفاتورة رسمية.
            </p>
            <div className="grid gap-2">
              <Label>وصف الشغل / الخامات المستخدمة</Label>
              <Textarea
                value={invoiceNotes}
                onChange={(e) => setInvoiceNotes(e.target.value)}
                placeholder="مثال: تغيير مواسير حمام ومطبخ + شريط تيفلون وسيليكون"
                rows={3}
              />
            </div>
            <div className="grid grid-cols-3 gap-3">
              <div className="grid gap-2">
                <Label>قيمة الخامات</Label>
                <Input type="number" inputMode="decimal" value={materialsCost} onChange={(e) => setMaterialsCost(e.target.value)} placeholder="0" />
              </div>
              <div className="grid gap-2">
                <Label>الأجرة</Label>
                <Input type="number" inputMode="decimal" value={laborCost} onChange={(e) => setLaborCost(e.target.value)} placeholder="0" />
              </div>
              <div className="grid gap-2">
                <Label>الانتقال</Label>
                <Input type="number" inputMode="decimal" value={transportCost} onChange={(e) => setTransportCost(e.target.value)} placeholder="0" />
              </div>
            </div>
            <div className="rounded-lg bg-secondary/20 p-3 text-sm font-bold flex justify-between">
              <span>الإجمالي</span>
              <span>{(Number(materialsCost) || 0) + (Number(laborCost) || 0) + (Number(transportCost) || 0)} ج.م</span>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setInvoiceFor(null)}>إلغاء</Button>
            <Button onClick={submitInvoice} disabled={submittingInvoice} className="bg-green-600 hover:bg-green-700 text-white">
              {submittingInvoice ? "جاري الإرسال..." : "إرسال للإدارة"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </SiteLayout>
  );
}
