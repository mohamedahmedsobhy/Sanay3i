/*
  Sanay3i — ProRegister
  - Registration form for craftsmen wanting to join Sanay3i
  - Saves a "pro application" row to Supabase for admin review
*/

import { useMemo, useState } from "react";
import SiteLayout from "@/components/SiteLayout";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";
import { sbInsert } from "@/lib/supabase";

type ProTrade = "سباك" | "كهربائي" | "نجار" | "دهان" | "تكييف" | "تنضيف" | "فني أجهزة" | "ميكانيكي سيارات" | "طوارئ" | "أخرى";

type ProApplication = {
  id: string;
  createdAt: string; // ISO
  status: "new" | "approved" | "rejected";
  name: string;
  phone: string;
  trade: ProTrade;
  city: string;
  experienceYears: string;
  bio: string;
  skills: string[];

  // Verification (images are stored as Data URLs for demo)
  nationalId: string;
  idFrontDataUrl: string;
  selfieDataUrl: string;
  idBackDataUrl?: string;
};

async function saveProApplication(p: ProApplication) {
  await sbInsert("pro_applications", {
    status: "new",
    name: p.name,
    phone: p.phone,
    trade: p.trade,
    city: p.city,
    experience_years: p.experienceYears,
    bio: p.bio,
    skills: p.skills,
    national_id: p.nationalId,
    id_front_data_url: p.idFrontDataUrl,
    id_back_data_url: p.idBackDataUrl || null,
    selfie_data_url: p.selfieDataUrl,
  });
}

function fileToDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ""));
    reader.onerror = () => reject(new Error("read_failed"));
    reader.readAsDataURL(file);
  });
}

async function pickImage(
  file: File | null,
  onValue: (dataUrl: string) => void,
  maxBytes = 1_800_000
) {
  if (!file) return;
  if (!file.type.startsWith("image/")) {
    toast.error("ارفع صورة فقط (JPG/PNG)");
    return;
  }
  if (file.size > maxBytes) {
    toast.error("حجم الصورة كبير", { description: "من فضلك ارفع صورة أصغر (أقل من ~2MB)." });
    return;
  }
  try {
    const dataUrl = await fileToDataUrl(file);
    onValue(dataUrl);
  } catch {
    toast.error("حصلت مشكلة في رفع الصورة");
  }
}

export default function ProRegister() {

  const cities = useMemo(
    () => [
      "القاهرة",
      "الجيزة",
      "الإسكندرية",
      "القليوبية",
      "المنوفية",
      "الشرقية",
      "الغربية",
      "الدقهلية",
      "البحيرة",
      "الفيوم",
      "أخرى",
    ],
    []
  );

  const [form, setForm] = useState({
    name: "",
    phone: "",
    trade: "سباك" as ProTrade,
    city: "القاهرة",
    experienceYears: "1-3",
    bio: "",
    skills: [] as string[],

    nationalId: "",
    idFrontDataUrl: "",
    idBackDataUrl: "",
    selfieDataUrl: "",
  });

  return (
    <SiteLayout>
      <section className="container-sanay3i section-sanay3i">
        <div className="grid gap-10 md:grid-cols-12 md:items-start">
          <div className="md:col-span-5">
            <h1 className="font-display text-3xl font-bold md:text-4xl">تسجيل الصنايعي</h1>
            <p className="mt-2 text-muted-foreground leading-7">
              دي صفحة تسجيل طلب انضمام حقيقية — بتتسجل في قاعدة البيانات
              وتتراجع من خلال داشبورد الإدارة.
            </p>

            <div className="mt-6 rounded-3xl border bg-secondary/40 p-4">
              <div className="text-sm font-semibold">هتستلم الطلبات إزاي؟</div>
              <ul className="mt-2 list-disc pr-5 text-sm text-muted-foreground leading-7">
                <li>بعد التسجيل الطلب بيتراجع من الإدارة.</li>
                <li>لو اتقبلت هيوصلك كود دخول لحساب الصنايعي.</li>
                <li>تقدر تشوف الطلبات اللي متعيّنة عليك بعد تسجيل الدخول.</li>
              </ul>
            </div>
          </div>

          <div className="md:col-span-7">
            <Card className="overflow-hidden card-elevated">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">بيانات الصنايعي</CardTitle>
              </CardHeader>
              <CardContent>
                <form
                  className="grid gap-4"
                  onSubmit={async (e) => {
                    e.preventDefault();
                    if (!form.name.trim() || !form.phone.trim()) {
                      toast.error("من فضلك اكتب الاسم ورقم الموبايل");
                      return;
                    }

                    if (!form.nationalId.trim() || form.nationalId.trim().length < 10) {
                      toast.error("من فضلك اكتب رقم البطاقة بشكل صحيح");
                      return;
                    }

                    if (!form.idFrontDataUrl || !form.selfieDataUrl) {
                      toast.error("مطلوب توثيق", { description: "ارفع صورة البطاقة (الوش) + صورة شخصية." });
                      return;
                    }

                    const profile: Omit<ProApplication, "createdAt" | "status"> = {
                      id: `pro_${Date.now()}`,
                      name: form.name.trim(),
                      phone: form.phone.trim(),
                      trade: form.trade,
                      city: form.city,
                      experienceYears: form.experienceYears,
                      bio: form.bio.trim(),
                      skills: form.skills,

                      nationalId: form.nationalId.trim(),
                      idFrontDataUrl: form.idFrontDataUrl,
                      idBackDataUrl: form.idBackDataUrl || undefined,
                      selfieDataUrl: form.selfieDataUrl,
                    };

                    const application: ProApplication = {
                      ...profile,
                      createdAt: new Date().toISOString(),
                      status: "new",
                    };
                    try {
                      await saveProApplication(application);
                    } catch (err) {
                      console.error(err);
                      toast.error("حصلت مشكلة في إرسال الطلب، حاول تاني");
                      return;
                    }
                    toast.success("تم إرسال طلب الانضمام", {
                      description: "هنراجعه ونتواصل معاك قريبًا.",
                    });

                    setForm({
                      name: "",
                      phone: "",
                      trade: "سباك" as ProTrade,
                      city: "القاهرة",
                      experienceYears: "1-3",
                      bio: "",
                      skills: [] as string[],
                      nationalId: "",
                      idFrontDataUrl: "",
                      idBackDataUrl: "",
                      selfieDataUrl: "",
                    });
                  }}
                >
                  <div className="grid gap-3 sm:grid-cols-2">
                    <div className="grid gap-2">
                      <label className="text-sm font-medium">الاسم</label>
                      <Input
                        value={form.name}
                        onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
                        placeholder="مثال: أحمد محمد"
                        required
                      />
                    </div>
                    <div className="grid gap-2">
                      <label className="text-sm font-medium">رقم الموبايل</label>
                      <Input
                        value={form.phone}
                        onChange={(e) => setForm((f) => ({ ...f, phone: e.target.value }))}
                        placeholder="مثال: 01xxxxxxxxx"
                        required
                      />
                    </div>
                  </div>

                  <div className="grid gap-3 sm:grid-cols-2">
                    <div className="grid gap-2">
                      <label className="text-sm font-medium">التخصص</label>
                      <Select
                        value={form.trade}
                        onValueChange={(v) => setForm((f) => ({ ...f, trade: v as ProTrade }))}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="اختار" />
                        </SelectTrigger>
                        <SelectContent>
                          {["سباك", "كهربائي", "نجار", "دهان", "تكييف", "تنضيف", "فني أجهزة", "ميكانيكي سيارات", "طوارئ", "أخرى"].map((x) => (
                            <SelectItem key={x} value={x}>
                              {x}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      
                      {(form.trade === "فني أجهزة" || form.trade === "ميكانيكي سيارات" || form.trade === "طوارئ") ? (
                        <div className="mt-3 rounded-2xl border bg-secondary/30 p-3">
                          <div className="text-sm font-semibold">اختار مهارات الصيانة</div>
                          <div className="mt-2 grid gap-2 sm:grid-cols-2 text-sm">
                            {(
                              form.trade === "فني أجهزة"
                                ? [
                                    "غسالات",
                                    "ثلاجات",
                                    "سخانات",
                                    "ميكروويف",
                                    "بوتاجازات",
                                    "تكييفات",
                                  ]
                                : form.trade === "ميكانيكي سيارات"
                                  ? [
                                      "فحص كمبيوتر",
                                      "كهرباء سيارات",
                                      "ميكانيكا",
                                      "عفشة وفرامل",
                                      "تكييف سيارات",
                                      "بطارية ودينامو",
                                    ]
                                  : [
                                      "ماس كهربائي",
                                      "عطل عربية في الطريق",
                                      "ماسورة اتكسرت",
                                      "أخرى",
                                    ]
                            ).map((skill) => {
                              const checked = form.skills.includes(skill);
                              return (
                                <label key={skill} className="flex items-center gap-2 rounded-xl border bg-background px-3 py-2">
                                  <input
                                    type="checkbox"
                                    checked={checked}
                                    onChange={(e) => {
                                      const on = e.target.checked;
                                      setForm((f) => {
                                        const next = on ? Array.from(new Set([...f.skills, skill])) : f.skills.filter((x) => x !== skill);
                                        return { ...f, skills: next };
                                      });
                                    }}
                                  />
                                  <span>{skill}</span>
                                </label>
                              );
                            })}
                          </div>
                          <div className="mt-2 text-xs text-muted-foreground leading-6">
                            * المهارات دي بتساعد الإدارة تختار الصنايعي المناسب حسب نوع الطلب.
                          </div>
                        </div>
                      ) : null}

</Select>
                    </div>

                    <div className="grid gap-2">
                      <label className="text-sm font-medium">المحافظة</label>
                      <Select value={form.city} onValueChange={(v) => setForm((f) => ({ ...f, city: v }))}>
                        <SelectTrigger>
                          <SelectValue placeholder="اختار" />
                        </SelectTrigger>
                        <SelectContent>
                          {cities.map((c) => (
                            <SelectItem key={c} value={c}>
                              {c}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="grid gap-3 sm:grid-cols-2">
                    <div className="grid gap-2">
                      <label className="text-sm font-medium">سنين الخبرة</label>
                      <Select
                        value={form.experienceYears}
                        onValueChange={(v) => setForm((f) => ({ ...f, experienceYears: v }))}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="اختار" />
                        </SelectTrigger>
                        <SelectContent>
                          {["أقل من سنة", "1-3", "3-7", "7+"]
                            .map((x) => (
                              <SelectItem key={x} value={x}>
                                {x}
                              </SelectItem>
                            ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="grid gap-2">
                      <label className="text-sm font-medium">كلمة مرور (اختياري)</label>
                      <Input placeholder="(اختياري)" type="password" disabled />
                    </div>
                  </div>

                  <div className="grid gap-2">
                    <label className="text-sm font-medium">نبذة قصيرة</label>
                    <Textarea
                      value={form.bio}
                      onChange={(e) => setForm((f) => ({ ...f, bio: e.target.value }))}
                      placeholder="مثال: شغل سباكة وصيانة سخانات…"
                      rows={4}
                    />
                  </div>

                  <div className="rounded-3xl border bg-secondary/25 p-4">
                    <div className="text-sm font-semibold">توثيق الهوية</div>
                    <div className="mt-2 text-xs text-muted-foreground leading-6">
                      مطلوب: صورة بطاقة (الوش) + صورة شخصية. (حد أقصى ~2MB لكل صورة)
                    </div>

                    <div className="mt-4 grid gap-3 sm:grid-cols-2">
                      <div className="grid gap-2">
                        <label className="text-sm font-medium">رقم البطاقة</label>
                        <Input
                          value={form.nationalId}
                          onChange={(e) => setForm((f) => ({ ...f, nationalId: e.target.value }))}
                          placeholder="مثال: 29XXXXXXXXXXXXX"
                          inputMode="numeric"
                        />
                      </div>

                      <div className="grid gap-2">
                        <label className="text-sm font-medium">صورة شخصية (سيلفي)</label>
                        <Input
                          type="file"
                          accept="image/*"
                          onChange={(e) =>
                            void pickImage(e.target.files?.[0] ?? null, (dataUrl) =>
                              setForm((f) => ({ ...f, selfieDataUrl: dataUrl }))
                            )
                          }
                        />
                        {form.selfieDataUrl ? (
                          <img
                            src={form.selfieDataUrl}
                            alt="Selfie preview"
                            className="mt-2 h-24 w-24 rounded-2xl border object-cover"
                          />
                        ) : null}
                      </div>
                    </div>

                    <div className="mt-4 grid gap-3 sm:grid-cols-2">
                      <div className="grid gap-2">
                        <label className="text-sm font-medium">صورة البطاقة (الوش)</label>
                        <Input
                          type="file"
                          accept="image/*"
                          onChange={(e) =>
                            void pickImage(e.target.files?.[0] ?? null, (dataUrl) =>
                              setForm((f) => ({ ...f, idFrontDataUrl: dataUrl }))
                            )
                          }
                        />
                        {form.idFrontDataUrl ? (
                          <img
                            src={form.idFrontDataUrl}
                            alt="ID front preview"
                            className="mt-2 h-24 w-full rounded-2xl border object-cover"
                          />
                        ) : null}
                      </div>

                      <div className="grid gap-2">
                        <label className="text-sm font-medium">صورة البطاقة (الظهر) — اختياري</label>
                        <Input
                          type="file"
                          accept="image/*"
                          onChange={(e) =>
                            void pickImage(e.target.files?.[0] ?? null, (dataUrl) =>
                              setForm((f) => ({ ...f, idBackDataUrl: dataUrl }))
                            )
                          }
                        />
                        {form.idBackDataUrl ? (
                          <img
                            src={form.idBackDataUrl}
                            alt="ID back preview"
                            className="mt-2 h-24 w-full rounded-2xl border object-cover"
                          />
                        ) : null}
                      </div>
                    </div>
                  </div>

                  <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
                    <Button type="submit" className="bg-primary text-primary-foreground hover:bg-primary/90">
إرسال طلب الانضمام
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </SiteLayout>
  );
}
