/*
  Sanay3i — Booking Page
  - Saves request + generates tracking code
  - WhatsApp is for inquiries only
*/

import { useMemo, useState } from "react";
import { format } from "date-fns";
import SiteLayout from "@/components/SiteLayout";
import PageHeader from "@/components/PageHeader";

import { Clock, BadgeCheck, Navigation, MapPin } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { sbInsert } from "@/lib/supabase";

const WHATSAPP_BUSINESS_NUMBER = "201270084490";

function buildInquiryMessage(p: {
  name: string;
  phone: string;
  service: string;
  city: string; // restored city
  addressDetails?: string;
  locationLink?: string;
  date: Date | null;
  slot: string;
  payment: string;
  notes: string;
}) {
  const lines = [
    "طلب حجز زيارة — Sanay3i",
    "-------------------------",
    `الاسم: ${p.name || "-"}`,
    `موبايل العميل: ${p.phone || "-"}`,
    `الخدمة: ${p.service || "-"}`,
    `المنطقة/المحافظة: ${p.city || "-"}`,
    `العنوان: ${p.addressDetails || "-"}`,
    `اللوكيشن: ${p.locationLink || "-"}`,
    `المعاد: ${p.date ? format(p.date, "yyyy-MM-dd") : "-"} ${p.slot ? `(${p.slot})` : ""}`.trim(),
    `طريقة الدفع: ${p.payment || "-"}`,
    `ملاحظات: ${p.notes?.trim() ? p.notes.trim() : "-"}`,
  ];
  return lines.join("\n");
}

const SERVICES = [
  "سباكة",
  "كهرباء",
  "دهان وتشطيب",
  "نجارة",
  "تكييف وصيانة",
  "تنضيف عميق",
  "إصلاح أجهزة كهربائية",
  "صيانة سيارات",
  "طوارئ",
] as const;
const CITIES = [
  "القاهرة",
  "الجيزة",
  "الإسكندرية",
  "القليوبية",
  "المنوفية",
  "الشرقية",
  "الغربية",
  "الدقهلية",
  "البحيرة",
  "الفيوم",
] as const;

function getQueryParam(name: string) {
  try {
    const hash = window.location.hash || "";
    const idx = hash.indexOf("?");
    if (idx === -1) return "";
    const qs = hash.slice(idx + 1);
    return new URLSearchParams(qs).get(name) || "";
  } catch {
    return "";
  }
}

function buildExtraNotes(form: any) {
  const lines: string[] = [];

  if (form.service === "سباكة") {
    const issue = form.plumbingIssue === "أخرى" ? form.plumbingIssueCustom : form.plumbingIssue;
    if (issue) lines.push(`نوع المشكلة: ${issue}`);
    if (form.plumbingLocation) lines.push(`مكان المشكلة: ${form.plumbingLocation}`);
  }

  if (form.service === "كهرباء") {
    const issue = form.electricIssue === "أخرى" ? form.electricIssueCustom : form.electricIssue;
    if (issue) lines.push(`نوع المشكلة: ${issue}`);
    if (form.electricLocation) lines.push(`مكان المشكلة: ${form.electricLocation}`);
  }

  if (form.service === "دهان وتشطيب") {
    const type = form.paintingType === "أخرى" ? form.paintingTypeCustom : form.paintingType;
    if (type) lines.push(`نوع الشغل: ${type}`);
    if (form.paintingArea) lines.push(`المساحة/المكان: ${form.paintingArea}`);
  }

  if (form.service === "نجارة") {
    const task = form.carpentryTask === "أخرى" ? form.carpentryTaskCustom : form.carpentryTask;
    if (task) lines.push(`نوع الشغل: ${task}`);
  }

  if (form.service === "تكييف وصيانة") {
    const task = form.acTask === "أخرى" ? form.acTaskCustom : form.acTask;
    if (task) lines.push(`نوع الصيانة: ${task}`);
  }

  if (form.service === "تنضيف عميق") {
    const type = form.cleaningType === "أخرى" ? form.cleaningTypeCustom : form.cleaningType;
    if (type) lines.push(`نوع التنضيف: ${type}`);
    if (form.cleaningArea) lines.push(`المكان/المساحة: ${form.cleaningArea}`);
  }

  if (form.service === "إصلاح أجهزة كهربائية") {
    if (form.applianceType) lines.push(`نوع الجهاز: ${form.applianceType}`);
    if (form.applianceFault) lines.push(`العطل: ${form.applianceFault}`);
  }

  if (form.service === "صيانة سيارات") {
    if (form.carServiceMode) lines.push(`نوع الخدمة: ${form.carServiceMode}`);
    if (form.carMakeModel) lines.push(`نوع/موديل العربية: ${form.carMakeModel}`);
    if (form.carFault) lines.push(`العطل: ${form.carFault}`);
    if (form.carLocation) lines.push(`لوكيشن العربية: ${form.carLocation}`);
  }

  if (form.service === "طوارئ") {
    if (form.emergencyType && form.emergencyType !== "اكتب الحالة بنفسك") {
      lines.push(`نوع الطوارئ: ${form.emergencyType}`);
    }
    if (form.emergencyType === "اكتب الحالة بنفسك" && form.emergencyCustom) {
      lines.push(`نوع الطوارئ: ${form.emergencyCustom}`);
    }
    if (form.emergencyLocation) lines.push(`لوكيشن الطوارئ: ${form.emergencyLocation}`);
  }

  return lines.join("\n");
}

function buildFinalNotes(form: any) {
  const extra = buildExtraNotes(form);
  const user = String(form.notes || "").trim();
  return [extra, user].filter(Boolean).join("\n\n").trim();
}

export default function BookingPage() {
  const timeSlots = useMemo(
    () => [
      "10:00 ص – 12:00 م",
      "12:00 م – 02:00 م",
      "02:00 م – 04:00 م",
      "04:00 م – 06:00 م",
      "06:00 م – 08:00 م",
      "08:00 م – 10:00 م",
    ],
    []
  );

  const paymentMethods = useMemo(
    () => ["كاش", "فودافون كاش", "إنستاباي", "تحويل بنكي", "بطاقة (عند التوفر)"],
    []
  );

  const presetService = useMemo(() => getQueryParam("service"), []);

  const tomorrow = useMemo(() => {
    const d = new Date();
    d.setDate(d.getDate() + 1);
    d.setHours(0, 0, 0, 0);
    return d;
  }, []);

  const [form, setForm] = useState({
    name: "",
    phone: "",
    service: presetService,
    city: "",
    addressDetails: "",
    locationLink: "",
    date: tomorrow as Date | null,
    slot: "10:00 ص – 12:00 م",
    payment: "كاش",

    // Extra (dynamic) fields based on selected service
    // Home services
    plumbingIssue: "",
    plumbingIssueCustom: "",
    plumbingLocation: "",

    electricIssue: "",
    electricIssueCustom: "",
    electricLocation: "",

    paintingType: "",
    paintingTypeCustom: "",
    paintingArea: "",

    carpentryTask: "",
    carpentryTaskCustom: "",

    acTask: "",
    acTaskCustom: "",

    cleaningType: "",
    cleaningTypeCustom: "",
    cleaningArea: "",

    // Appliances / cars / emergency
    applianceType: "",
    applianceFault: "",

    carServiceMode: "زيارة مكان العربية",
    carMakeModel: "",
    carFault: "",
    carLocation: "",

    emergencyType: "ماس كهربائي",
    emergencyCustom: "",
    emergencyLocation: "",

    notes: "",
  });

  const [lastTrackingCode, setLastTrackingCode] = useState("");

  return (
    <SiteLayout>
      <PageHeader title="احجز زيارة" subtitle="املا البيانات وحدد المعاد وطريقة الدفع — وبعدها هيظهر لك رقم متابعة للطلب." />
      <section className="container-sanay3i section-sanay3i pt-0">
        <div>
          <h1 className="font-display text-3xl font-bold md:text-5xl">احجز زيارة</h1>
          <p className="mt-2 text-muted-foreground">املا البيانات واضغط إرسال — هيظهر لك رقم متابعة تقدر تراجع بيه حالة الطلب.</p>
        </div>

        {lastTrackingCode ? (
          <div className="mt-8 mb-10">
            <Card className="border-primary bg-primary/5 card-elevated">
              <CardContent className="flex flex-col items-center justify-center p-8 text-center">
                <div className="rounded-full bg-primary/10 p-3 text-primary mb-4">
                  <BadgeCheck className="h-8 w-8" />
                </div>
                <h2 className="text-2xl font-bold">تم إرسال طلبك بنجاح!</h2>
                <p className="mt-2 text-muted-foreground">رقم المتابعة الخاص بك هو:</p>
                <div className="mt-4 flex items-center gap-3 rounded-2xl border bg-card p-4 shadow-sm">
                  <span className="font-mono text-3xl font-bold tracking-widest text-primary">{lastTrackingCode}</span>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => {
                      navigator.clipboard.writeText(lastTrackingCode);
                      toast.success("تم نسخ الكود");
                    }}
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect width="14" height="14" x="8" y="8" rx="2" ry="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/></svg>
                  </Button>
                </div>
                <p className="mt-4 text-sm text-muted-foreground max-w-md">
                  احفظ الرقم ده عشان تقدر تتابع حالة الطلب من صفحة "متابعة الطلب". فريقنا هيتواصل معاك قريب لتأكيد المعاد.
                </p>
                <div className="mt-6 flex gap-3">
                  <a href="#/track">
                    <Button>متابعة الطلب الآن</Button>
                  </a>
                  <Button variant="outline" onClick={() => setLastTrackingCode("")}>حجز طلب جديد</Button>
                </div>
              </CardContent>
            </Card>
          </div>
        ) : null}

        <div className="mt-8 grid gap-6 md:grid-cols-12 md:items-start">
          <div className="md:col-span-7">
            <Card className="overflow-hidden card-elevated">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">تفاصيل الطلب</CardTitle>
              </CardHeader>
              <CardContent>
                <form
                  className="grid gap-4"
                  onSubmit={async (e) => {
                    e.preventDefault();
                    const finalNotes = buildFinalNotes(form);

                    // Dynamic validation per service
                    if (form.service === "سباكة" && !form.plumbingIssue) {
                      toast.error("اختار نوع مشكلة السباكة");
                      return;
                    }
                    if (form.service === "كهرباء" && !form.electricIssue) {
                      toast.error("اختار نوع مشكلة الكهرباء");
                      return;
                    }
                    if (form.service === "دهان وتشطيب" && !form.paintingType) {
                      toast.error("اختار نوع الشغل في الدهان/التشطيب");
                      return;
                    }
                    if (form.service === "نجارة" && !form.carpentryTask) {
                      toast.error("اختار نوع شغل النجارة");
                      return;
                    }
                    if (form.service === "تكييف وصيانة" && !form.acTask) {
                      toast.error("اختار نوع صيانة التكييف");
                      return;
                    }
                    if (form.service === "تنضيف عميق" && !form.cleaningType) {
                      toast.error("اختار نوع التنضيف");
                      return;
                    }

                    if (form.service === "إصلاح أجهزة كهربائية" && (!form.applianceType || !form.applianceFault)) {
                      toast.error("من فضلك اكتب نوع الجهاز والعطل");
                      return;
                    }
                    if (form.service === "صيانة سيارات" && (!form.carServiceMode || !form.carFault || !form.carLocation)) {
                      toast.error("من فضلك اكتب العطل ولوكيشن العربية");
                      return;
                    }
                    if (form.service === "طوارئ") {
                      if (!form.emergencyType) {
                        toast.error("اختار نوع الطوارئ");
                        return;
                      }
                      if (form.emergencyType === "اكتب الحالة بنفسك" && !String(form.emergencyCustom || "").trim()) {
                        toast.error("اكتب الحالة الطارئة");
                        return;
                      }
                      if (!String(form.emergencyLocation || "").trim()) {
                        toast.error("من فضلك اكتب لوكيشن الطوارئ (لينك/وصف)");
                        return;
                      }
                    }
                    if (!form.service || !form.city || !form.date || !form.slot || !form.payment) {
                      toast.error("من فضلك كمّل البيانات (الخدمة/المنطقة/المعاد/الدفع)");
                      return;
                    }
                    let trackingCode = "";
                    try {
                      trackingCode = String(Date.now()).slice(-6);
                      await sbInsert("bookings", {
                        tracking_code: trackingCode,
                        customer_name: form.name,
                        customer_phone: form.phone,
                        service: form.service,
                        city: form.city,
                        date_iso: form.date ? format(form.date, "yyyy-MM-dd") : null,
                        slot: form.slot,
                        payment: form.payment,
                        address: form.addressDetails,
                        location_url: form.locationLink,
                        notes: finalNotes,
                        status: "new",
                      });
                    } catch (err) {
                      console.error(err);
                      toast.error("حصلت مشكلة في إرسال الطلب، حاول تاني");
                      return;
                    }

                    toast.success("تم استلام طلبك", {
                      description: trackingCode ? `رقم المتابعة: ${trackingCode}` : "تم حفظ الطلب.",
                    });

                    if (trackingCode) {
                      setLastTrackingCode(trackingCode);
                    }

                    setForm({
                      name: "",
                      phone: "",
                      service: "",
                      city: "",
                      addressDetails: "",
                      locationLink: "",
                      date: null,
                      slot: "",
                      payment: "",

                      plumbingIssue: "",
                      plumbingIssueCustom: "",
                      plumbingLocation: "",

                      electricIssue: "",
                      electricIssueCustom: "",
                      electricLocation: "",

                      paintingType: "",
                      paintingTypeCustom: "",
                      paintingArea: "",

                      carpentryTask: "",
                      carpentryTaskCustom: "",

                      acTask: "",
                      acTaskCustom: "",

                      cleaningType: "",
                      cleaningTypeCustom: "",
                      cleaningArea: "",

                      applianceType: "",
                      applianceFault: "",

                      carServiceMode: "زيارة مكان العربية",
                      carMakeModel: "",
                      carFault: "",
                      carLocation: "",

                      emergencyType: "ماس كهربائي",
                      emergencyCustom: "",
                      emergencyLocation: "",

                      notes: "",
                    });
                  }}
                >
                  <div className="grid gap-3 sm:grid-cols-2">
                    <div className="grid gap-2">
                      <label className="text-sm font-medium">الاسم</label>
                      <Input
                        required
                        placeholder="مثال: محمد"
                        value={form.name}
                        onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
                      />
                    </div>
                    <div className="grid gap-2">
                      <label className="text-sm font-medium">رقم الموبايل</label>
                      <Input
                        required
                        inputMode="tel"
                        placeholder="01xxxxxxxxx"
                        value={form.phone}
                        onChange={(e) => setForm((f) => ({ ...f, phone: e.target.value }))}
                      />
                    </div>
                  </div>

                  {/* Address Section */}
                  <div className="rounded-xl border bg-secondary/10 p-4 space-y-3">
                    <div className="flex items-center justify-between">
                      <label className="text-sm font-semibold flex items-center gap-2">
                        <MapPin className="h-4 w-4 text-primary" />
                        العنوان بالتفصيل
                      </label>
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        className="h-8 gap-2 text-xs"
                        onClick={() => {
                          if (!navigator.geolocation) {
                            toast.error("المتصفح لا يدعم تحديد الموقع");
                            return;
                          }
                          const id = toast.loading("جاري تحديد الموقع...");
                          navigator.geolocation.getCurrentPosition(
                            (pos) => {
                              const link = `https://maps.google.com/?q=${pos.coords.latitude},${pos.coords.longitude}`;
                              setForm(f => ({ ...f, locationLink: link }));
                              toast.dismiss(id);
                              toast.success("تم تحديد الموقع بنجاح");
                            },
                            (err) => {
                              toast.dismiss(id);
                              toast.error("فشل تحديد الموقع: " + err.message);
                            }
                          );
                        }}
                      >
                        <Navigation className="h-3 w-3" />
                        موقعي الحالي
                      </Button>
                    </div>
                    
                    <Textarea 
                      placeholder="اسم الشارع، رقم العمارة، الدور، الشقة..."
                      className="min-h-[80px]"
                      value={form.addressDetails}
                      onChange={(e) => setForm(f => ({ ...f, addressDetails: e.target.value }))}
                    />

                    {form.locationLink && (
                      <div className="flex items-center gap-2 text-xs text-green-600 bg-green-500/10 p-2 rounded-md">
                        <BadgeCheck className="h-4 w-4" />
                        تم حفظ اللوكيشن: <a href={form.locationLink} target="_blank" rel="noreferrer" className="underline hover:text-green-700">عرض الموقع</a>
                      </div>
                    )}
                  </div>

                  <div className="grid gap-3 sm:grid-cols-2">
                    <div className="grid gap-2">
                      <label className="text-sm font-medium">الخدمة</label>
                      <Select required value={form.service} onValueChange={(v) => setForm((f) => ({ ...f, service: v }))}>
                        <SelectTrigger>
                          <SelectValue placeholder="اختار الخدمة" />
                        </SelectTrigger>
                        <SelectContent>
                          {SERVICES.map((s) => (
                            <SelectItem key={s} value={s}>
                              {s}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="grid gap-2">
                      <label className="text-sm font-medium">المنطقة</label>
                      <Select required value={form.city} onValueChange={(v) => setForm((f) => ({ ...f, city: v }))}>
                        <SelectTrigger>
                          <SelectValue placeholder="اختار المحافظة" />
                        </SelectTrigger>
                        <SelectContent>
                          {CITIES.map((c) => (
                            <SelectItem key={c} value={c}>
                              {c}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="grid gap-3 sm:grid-cols-2">
                    <div className="grid gap-2">
                      <label className="text-sm font-medium">المعاد</label>
                      <Popover>
                        <PopoverTrigger asChild>
                          <Button
                            type="button"
                            variant="outline"
                            className={cn("w-full justify-between", !form.date && "text-muted-foreground")}
                          >
                            {form.date ? format(form.date, "yyyy-MM-dd") : "اختار التاريخ"}
                            <Clock className="h-4 w-4 opacity-70" />
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent align="start" className="w-auto p-2">
                          <Calendar
                            mode="single"
                            selected={form.date ?? undefined}
                            onSelect={(d) => setForm((f) => ({ ...f, date: d ?? null }))}
                            disabled={(d) => d < new Date(new Date().setHours(0, 0, 0, 0))}
                            initialFocus
                          />
                        </PopoverContent>
                      </Popover>
                    </div>

                    <div className="grid gap-2">
                      <label className="text-sm font-medium">الوقت</label>
                      <Select required value={form.slot} onValueChange={(v) => setForm((f) => ({ ...f, slot: v }))}>
                        <SelectTrigger>
                          <SelectValue placeholder="اختار الوقت المناسب" />
                        </SelectTrigger>
                        <SelectContent>
                          {timeSlots.map((t) => (
                            <SelectItem key={t} value={t}>
                              {t}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="grid gap-2">
                    <label className="text-sm font-medium">طريقة الدفع</label>
                    <Select required value={form.payment} onValueChange={(v) => setForm((f) => ({ ...f, payment: v }))}>
                      <SelectTrigger>
                        <SelectValue placeholder="اختار طريقة الدفع" />
                      </SelectTrigger>
                      <SelectContent>
                        {paymentMethods.map((p) => (
                          <SelectItem key={p} value={p}>
                            {p}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>



                  {/* تفاصيل إضافية للخدمة */}

                  {form.service === "سباكة" ? (
                    <div className="grid gap-3 rounded-2xl border bg-secondary/20 p-4">
                      <div className="text-sm font-semibold">تفاصيل السباكة</div>
                      <div className="grid gap-3 sm:grid-cols-2">
                        <div className="grid gap-2">
                          <label className="text-sm font-medium">نوع المشكلة</label>
                          <Select value={form.plumbingIssue} onValueChange={(v) => setForm((f) => ({ ...f, plumbingIssue: v }))}>
                            <SelectTrigger>
                              <SelectValue placeholder="اختار" />
                            </SelectTrigger>
                            <SelectContent>
                              {["تسريب مياه", "انسداد صرف", "سخان", "تأسيس سباكة", "ضغط مياه", "تركيبات خلاطات", "أخرى"].map((x) => (
                                <SelectItem key={x} value={x}>
                                  {x}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          {form.plumbingIssue === "أخرى" && (
                            <Input
                              placeholder="اكتب نوع المشكلة بالتفصيل"
                              value={form.plumbingIssueCustom}
                              onChange={(e) => setForm((f) => ({ ...f, plumbingIssueCustom: e.target.value }))}
                              className="mt-2"
                            />
                          )}
                        </div>
                        <div className="grid gap-2">
                          <label className="text-sm font-medium">مكان المشكلة (اختياري)</label>
                          <Input
                            placeholder="مثال: مطبخ / حمام / تحت الحوض"
                            value={form.plumbingLocation}
                            onChange={(e) => setForm((f) => ({ ...f, plumbingLocation: e.target.value }))}
                          />
                        </div>
                      </div>
                    </div>
                  ) : null}

                  {form.service === "كهرباء" ? (
                    <div className="grid gap-3 rounded-2xl border bg-secondary/20 p-4">
                      <div className="text-sm font-semibold">تفاصيل الكهرباء</div>
                      <div className="grid gap-3 sm:grid-cols-2">
                        <div className="grid gap-2">
                          <label className="text-sm font-medium">نوع المشكلة</label>
                          <Select value={form.electricIssue} onValueChange={(v) => setForm((f) => ({ ...f, electricIssue: v }))}>
                            <SelectTrigger>
                              <SelectValue placeholder="اختار" />
                            </SelectTrigger>
                            <SelectContent>
                              {["قاطع بيفصل", "ماس كهربائي", "مشكلة إنارة", "فيشة/بريزة مش شغالة", "لوحة مفاتيح", "تأسيس كهرباء", "أخرى"].map((x) => (
                                <SelectItem key={x} value={x}>
                                  {x}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          {form.electricIssue === "أخرى" && (
                            <Input
                              placeholder="اكتب نوع المشكلة بالتفصيل"
                              value={form.electricIssueCustom}
                              onChange={(e) => setForm((f) => ({ ...f, electricIssueCustom: e.target.value }))}
                              className="mt-2"
                            />
                          )}
                        </div>
                        <div className="grid gap-2">
                          <label className="text-sm font-medium">مكان المشكلة (اختياري)</label>
                          <Input
                            placeholder="مثال: صالة / غرفة / مطبخ"
                            value={form.electricLocation}
                            onChange={(e) => setForm((f) => ({ ...f, electricLocation: e.target.value }))}
                          />
                        </div>
                      </div>
                      <div className="text-xs text-muted-foreground leading-6">
                        لو في ريحة حريق/شرر واضح، اختار "طوارئ".
                      </div>
                    </div>
                  ) : null}

                  {form.service === "دهان وتشطيب" ? (
                    <div className="grid gap-3 rounded-2xl border bg-secondary/20 p-4">
                      <div className="text-sm font-semibold">تفاصيل الدهان/التشطيب</div>
                      <div className="grid gap-3 sm:grid-cols-2">
                        <div className="grid gap-2">
                          <label className="text-sm font-medium">نوع الشغل</label>
                          <Select value={form.paintingType} onValueChange={(v) => setForm((f) => ({ ...f, paintingType: v }))}>
                            <SelectTrigger>
                              <SelectValue placeholder="اختار" />
                            </SelectTrigger>
                            <SelectContent>
                              {["دهان حوائط كاملة", "معجون وصنفرة", "مرمات بسيطة", "دهان أبواب وشبابيك", "ورق حائط", "أخرى"].map((x) => (
                                <SelectItem key={x} value={x}>
                                  {x}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          {form.paintingType === "أخرى" && (
                            <Input
                              placeholder="اكتب نوع الشغل المطلوب"
                              value={form.paintingTypeCustom}
                              onChange={(e) => setForm((f) => ({ ...f, paintingTypeCustom: e.target.value }))}
                              className="mt-2"
                            />
                          )}
                        </div>
                        <div className="grid gap-2">
                          <label className="text-sm font-medium">المكان/المساحة (اختياري)</label>
                          <Input
                            placeholder="مثال: أوضة نوم / شقة كاملة / حائط واحد"
                            value={form.paintingArea}
                            onChange={(e) => setForm((f) => ({ ...f, paintingArea: e.target.value }))}
                          />
                        </div>
                      </div>
                    </div>
                  ) : null}

                  {form.service === "نجارة" ? (
                    <div className="grid gap-3 rounded-2xl border bg-secondary/20 p-4">
                      <div className="text-sm font-semibold">تفاصيل النجارة</div>
                      <div className="grid gap-2">
                        <label className="text-sm font-medium">نوع الشغل</label>
                        <Select value={form.carpentryTask} onValueChange={(v) => setForm((f) => ({ ...f, carpentryTask: v }))}>
                          <SelectTrigger>
                            <SelectValue placeholder="اختار" />
                          </SelectTrigger>
                          <SelectContent>
                            {["إصلاح باب / كالون", "إصلاح مطبخ", "تعديل دولاب", "فك وتركيب أثاث", "نجارة باب وشباك", "أخرى"].map((x) => (
                              <SelectItem key={x} value={x}>
                                {x}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        {form.carpentryTask === "أخرى" && (
                          <Input
                            placeholder="اكتب نوع شغل النجارة بالتفصيل"
                            value={form.carpentryTaskCustom}
                            onChange={(e) => setForm((f) => ({ ...f, carpentryTaskCustom: e.target.value }))}
                            className="mt-2"
                          />
                        )}
                      </div>
                    </div>
                  ) : null}

                  {form.service === "تكييف وصيانة" ? (
                    <div className="grid gap-3 rounded-2xl border bg-secondary/20 p-4">
                      <div className="text-sm font-semibold">تفاصيل التكييف</div>
                      <div className="grid gap-2">
                        <label className="text-sm font-medium">نوع الصيانة</label>
                        <Select value={form.acTask} onValueChange={(v) => setForm((f) => ({ ...f, acTask: v }))}>
                          <SelectTrigger>
                            <SelectValue placeholder="اختار" />
                          </SelectTrigger>
                          <SelectContent>
                            {["تنظيف وغسيل التكييف", "شحن فريون", "تركيب تكييف جديد", "فك ونقل تكييف", "إصلاح أعطال / تسريب", "أخرى"].map((x) => (
                              <SelectItem key={x} value={x}>
                                {x}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        {form.acTask === "أخرى" && (
                          <Input
                            placeholder="اكتب العطل أو الخدمة المطلوبة"
                            value={form.acTaskCustom}
                            onChange={(e) => setForm((f) => ({ ...f, acTaskCustom: e.target.value }))}
                            className="mt-2"
                          />
                        )}
                      </div>
                    </div>
                  ) : null}

                  {form.service === "تنضيف عميق" ? (
                    <div className="grid gap-3 rounded-2xl border bg-secondary/20 p-4">
                      <div className="text-sm font-semibold">تفاصيل التنضيف العميق</div>
                      <div className="grid gap-3 sm:grid-cols-2">
                        <div className="grid gap-2">
                          <label className="text-sm font-medium">نوع التنضيف</label>
                          <Select value={form.cleaningType} onValueChange={(v) => setForm((f) => ({ ...f, cleaningType: v }))}>
                            <SelectTrigger>
                              <SelectValue placeholder="اختار" />
                            </SelectTrigger>
                            <SelectContent>
                              {["تنظيف شقة كاملة", "تنظيف مكتب / شركة", "تنظيف مطبخ عميق", "غسيل سجاد / موكيت", "تنظيف كنب / مفروشات", "أخرى"].map((x) => (
                                <SelectItem key={x} value={x}>
                                  {x}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          {form.cleaningType === "أخرى" && (
                            <Input
                              placeholder="اكتب نوع التنضيف المطلوب"
                              value={form.cleaningTypeCustom}
                              onChange={(e) => setForm((f) => ({ ...f, cleaningTypeCustom: e.target.value }))}
                              className="mt-2"
                            />
                          )}
                        </div>
                        <div className="grid gap-2">
                          <label className="text-sm font-medium">المكان/المساحة (اختياري)</label>
                          <Input
                            placeholder="مثال: 2 أوضة + صالة"
                            value={form.cleaningArea}
                            onChange={(e) => setForm((f) => ({ ...f, cleaningArea: e.target.value }))}
                          />
                        </div>
                      </div>
                    </div>
                  ) : null}

                  {form.service === "إصلاح أجهزة كهربائية" ? (
                    <div className="grid gap-3 rounded-2xl border bg-secondary/20 p-4">
                      <div className="text-sm font-semibold">تفاصيل الجهاز</div>
                      <div className="grid gap-3 sm:grid-cols-2">
                        <div className="grid gap-2">
                          <label className="text-sm font-medium">نوع الجهاز</label>
                          <Input
                            placeholder="مثال: غسالة / ثلاجة / سخان / ميكروويف"
                            value={form.applianceType}
                            onChange={(e) => setForm((f) => ({ ...f, applianceType: e.target.value }))}
                            required
                          />
                        </div>
                        <div className="grid gap-2">
                          <label className="text-sm font-medium">العطل</label>
                          <Input
                            placeholder="مثال: مش بيشتغل / صوت عالي / تسريب"
                            value={form.applianceFault}
                            onChange={(e) => setForm((f) => ({ ...f, applianceFault: e.target.value }))}
                            required
                          />
                        </div>
                      </div>
                    </div>
                  ) : null}

                  {form.service === "صيانة سيارات" ? (
                    <div className="grid gap-3 rounded-2xl border bg-secondary/20 p-4">
                      <div className="text-sm font-semibold">تفاصيل العربية</div>
                      <div className="grid gap-3">
                        <div className="grid gap-2">
                          <label className="text-sm font-medium">طريقة الخدمة</label>
                          <Select value={form.carServiceMode} onValueChange={(v) => setForm((f) => ({ ...f, carServiceMode: v }))}>
                            <SelectTrigger>
                              <SelectValue placeholder="اختار" />
                            </SelectTrigger>
                            <SelectContent>
                              {["زيارة مكان العربية", "استلام وتسليم العربية"].map((x) => (
                                <SelectItem key={x} value={x}>
                                  {x}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <div className="text-xs text-muted-foreground leading-6">
                            * "استلام وتسليم" يعني حد من عندنا يستلم العربية، والفني يخلص الكشف/الإصلاح، وبعدين تسليم للعميل.
                          </div>
                        </div>

                        <div className="grid gap-3 sm:grid-cols-2">
                          <div className="grid gap-2">
                            <label className="text-sm font-medium">نوع/موديل العربية (اختياري)</label>
                            <Input
                              placeholder="مثال: Hyundai Elantra 2018"
                              value={form.carMakeModel}
                              onChange={(e) => setForm((f) => ({ ...f, carMakeModel: e.target.value }))}
                            />
                          </div>
                          <div className="grid gap-2">
                            <label className="text-sm font-medium">العطل</label>
                            <Input
                              placeholder="مثال: العربية مش بتدور / لمبة شيك إنجن"
                              value={form.carFault}
                              onChange={(e) => setForm((f) => ({ ...f, carFault: e.target.value }))}
                              required
                            />
                          </div>
                        </div>

                        <div className="grid gap-2">
                          <label className="text-sm font-medium">لوكيشن العربية</label>
                          <Input
                            placeholder="لينك Google Maps أو وصف مختصر للمكان"
                            value={form.carLocation}
                            onChange={(e) => setForm((f) => ({ ...f, carLocation: e.target.value }))}
                            required
                          />
                        </div>
                      </div>
                    </div>
                  ) : null}

                  {form.service === "طوارئ" ? (
                    <div className="grid gap-3 rounded-2xl border bg-secondary/20 p-4">
                      <div className="text-sm font-semibold">تفاصيل الحالة الطارئة</div>
                      <div className="grid gap-3">
                        <div className="grid gap-2">
                          <label className="text-sm font-medium">نوع الطوارئ</label>
                          <Select value={form.emergencyType} onValueChange={(v) => setForm((f) => ({ ...f, emergencyType: v }))}>
                            <SelectTrigger>
                              <SelectValue placeholder="اختار" />
                            </SelectTrigger>
                            <SelectContent>
                              {["ماس كهربائي", "العربية عطلت في الطريق", "ماسورة اتكسرت", "اكتب الحالة بنفسك"].map((x) => (
                                <SelectItem key={x} value={x}>
                                  {x}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>

                        {form.emergencyType === "اكتب الحالة بنفسك" ? (
                          <div className="grid gap-2">
                            <label className="text-sm font-medium">اكتب الحالة</label>
                            <Textarea
                              rows={3}
                              placeholder="اكتب تفاصيل الحالة الطارئة…"
                              value={form.emergencyCustom}
                              onChange={(e) => setForm((f) => ({ ...f, emergencyCustom: e.target.value }))}
                              required
                            />
                          </div>
                        ) : null}

                        <div className="grid gap-2">
                          <label className="text-sm font-medium">لوكيشن الطوارئ</label>
                          <Input
                            placeholder="لينك Google Maps أو وصف للمكان"
                            value={form.emergencyLocation}
                            onChange={(e) => setForm((f) => ({ ...f, emergencyLocation: e.target.value }))}
                            required
                          />
                        </div>
                      </div>
                    </div>
                  ) : null}

                  <div className="grid gap-2">
                    <label className="text-sm font-medium">ملاحظات</label>
                    <Textarea
                      placeholder="مثال: تسريب تحت الحوض / محتاج فحص فقط…"
                      rows={4}
                      value={form.notes}
                      onChange={(e) => setForm((f) => ({ ...f, notes: e.target.value }))}
                    />
                  </div>

                  <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                    <Button type="submit" className="bg-primary text-primary-foreground hover:bg-primary/90">
                      إرسال الطلب
                    </Button>
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => {
                        const msg = buildInquiryMessage({ ...form, notes: buildFinalNotes(form) });
                        const waUrl = `https://wa.me/${WHATSAPP_BUSINESS_NUMBER}?text=${encodeURIComponent(msg)}`;
                        window.open(waUrl, "_blank", "noopener,noreferrer");
                      }}
                    >
                      واتساب للاستفسار
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          </div>

          <div className="md:col-span-5">
            <Card className="overflow-hidden card-elevated">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">معلومات مهمة</CardTitle>
              </CardHeader>
              <CardContent className="text-sm leading-7 text-muted-foreground">
                بعد الإرسال هيظهر لك رقم متابعة — استخدمه في صفحة متابعة الطلب.
                لو عندك صور/فيديو للمشكلة ابعتها في نفس المحادثة.
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </SiteLayout>
  );
}
