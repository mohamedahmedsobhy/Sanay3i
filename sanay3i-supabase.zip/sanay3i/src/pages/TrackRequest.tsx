/*
  Sanay3i — TrackRequest
  - Customer looks up a booking by tracking code via the track_booking() RPC
  - Reschedule/cancel/rate go through anon-safe RPC + ratings table calls
*/
import { useMemo, useState } from "react";
import SiteLayout from "@/components/SiteLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { format } from "date-fns";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { Clock, MessageCircle } from "lucide-react";
import { sbDelete, sbRpc, sbUpsert } from "@/lib/supabase";

type BookingRating = {
  stars: number; // 1-5
  comment?: string;
  ratedAt: string; // ISO
};

type BookingRequest = {
  id: string;
  trackingCode?: string;
  createdAt: string;
  customerName: string;
  customerPhone: string;
  service: string;
  city: string;
  dateISO: string;
  slot: string;
  payment: string;
  notes: string;
  status: string;
  assignedProId?: string;
  assignedProSnapshot?: null | { id: string; name: string; phone: string; trade: string; city?: string };
  rating?: BookingRating;
  invoiceStatus?: string;
};

// Maps a row from the track_booking() RPC to the shape this page uses
function fromRow(row: any): BookingRequest {
  return {
    id: row.id,
    trackingCode: row.tracking_code,
    createdAt: row.created_at,
    customerName: row.customer_name,
    customerPhone: row.customer_phone,
    service: row.service,
    city: row.city,
    dateISO: row.date_iso,
    slot: row.slot,
    payment: row.payment,
    notes: row.notes,
    status: row.status,
    assignedProId: row.assigned_pro_id || "",
    assignedProSnapshot: row.pro_name
      ? { id: row.assigned_pro_id, name: row.pro_name, phone: row.pro_phone, trade: row.pro_trade, city: row.pro_city }
      : null,
    rating:
      typeof row.rating_stars === "number"
        ? { stars: row.rating_stars, comment: row.rating_comment, ratedAt: row.rating_rated_at }
        : undefined,
    invoiceStatus: row.invoice_status || undefined,
  };
}

async function fetchByTrackingCode(code: string): Promise<BookingRequest | null> {
  const rows = await sbRpc<any[]>("track_booking", { p_code: code });
  return rows && rows.length ? fromRow(rows[0]) : null;
}

function statusBadge(s: string) {
  if (s === "new") return <Badge className="bg-accent text-accent-foreground">طلب جديد</Badge>;
  if (s === "contacted") return <Badge className="bg-blue-600 text-white">جاري التنفيذ</Badge>;
  if (s === "assigned") return <Badge className="bg-primary text-primary-foreground">جاري التجهيز</Badge>;
  if (s === "work_completed") return <Badge className="bg-green-600 text-white">تم التنفيذ</Badge>;
  if (s === "cancelled") return <Badge variant="destructive">ملغي</Badge>;
  return <Badge variant="secondary">مكتمل</Badge>;
}

export default function TrackRequest() {
  const [code, setCode] = useState("");
  const [found, setFound] = useState<BookingRequest | null>(null);

  const [rateStars, setRateStars] = useState(5);
  const [rateComment, setRateComment] = useState("");

  // Edit states
  const [editDate, setEditDate] = useState<Date | null>(null);
  const [editSlot, setEditSlot] = useState("");
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);

  const timeSlots = useMemo(
    () => [
      "10:00 ص – 12:00 م",
      "12:00 م – 02:00 م",
      "02:00 م – 04:00 م",
      "04:00 م – 06:00 م",
      "06:00 م – 08:00 م",
      "08:00 م – 10:00 م",
    ],
    []
  );

  const hint = useMemo(() => "رقم المتابعة بيكون 6 أرقام", []);

  // Patches booking status/date/slot via the anon-safe RPCs — ratings live in their own table, see saveRating/removeRating
  const handleUpdate = async (updates: { status?: string; dateISO?: string; slot?: string }) => {
    if (!found) return;
    try {
      if (updates.status === "cancelled") {
        await sbRpc("cancel_booking", { p_id: found.id });
      }
      if (updates.dateISO !== undefined || updates.slot !== undefined) {
        await sbRpc("reschedule_booking", {
          p_id: found.id,
          p_date: updates.dateISO ?? found.dateISO,
          p_slot: updates.slot ?? found.slot,
        });
      }
      setFound({ ...found, ...updates });
    } catch (err) {
      console.error(err);
      toast.error("حصلت مشكلة، حاول تاني");
    }
  };

  const saveRating = async (stars: number, comment: string) => {
    if (!found) return;
    try {
      const row = await sbUpsert<any>(
        "ratings",
        { booking_id: found.id, stars, comment: comment || null },
        "booking_id"
      );
      setFound({ ...found, rating: { stars: row.stars, comment: row.comment, ratedAt: row.rated_at } });
      toast.success("تم حفظ التقييم");
    } catch (err) {
      console.error(err);
      toast.error("حصلت مشكلة في حفظ التقييم");
    }
  };

  const removeRating = async () => {
    if (!found) return;
    try {
      await sbDelete("ratings", { booking_id: `eq.${found.id}` });
      const { rating, ...rest } = found;
      setFound(rest);
      toast.message("تم حذف التقييم");
    } catch (err) {
      console.error(err);
      toast.error("حصلت مشكلة في حذف التقييم");
    }
  };

  const cancelRequest = async () => {
    if (confirm("هل أنت متأكد من إلغاء الطلب؟")) {
      await handleUpdate({ status: "cancelled" });
      toast.success("تم إلغاء الطلب بنجاح");
    }
  };

  const saveReschedule = async () => {
    if (!editDate || !editSlot) {
      toast.error("برجاء اختيار التاريخ والوقت");
      return;
    }
    await handleUpdate({
      dateISO: format(editDate, "yyyy-MM-dd"),
      slot: editSlot,
    });
    toast.success("تم تعديل الميعاد بنجاح");
    setIsEditDialogOpen(false);
  };

  return (
    <SiteLayout>
      <section className="container-sanay3i section-sanay3i">
        <div className="mx-auto w-full max-w-2xl">
          <h1 className="font-display text-3xl font-bold md:text-4xl">متابعة الطلب</h1>
          <p className="mt-2 text-muted-foreground leading-7">
            اكتب رقم المتابعة اللي ظهر لك بعد إرسال الطلب علشان تشوف الحالة وتفاصيل التعيين.
          </p>

          <Card className="mt-6 overflow-hidden card-elevated">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">ابحث برقم المتابعة</CardTitle>
            </CardHeader>
            <CardContent>
              <form
                className="flex flex-col gap-3 sm:flex-row sm:items-end"
                onSubmit={async (e) => {
                  e.preventDefault();
                  const c = code.trim();
                  let req: BookingRequest | null = null;
                  try {
                    req = await fetchByTrackingCode(c);
                  } catch (err) {
                    console.error(err);
                    toast.error("حصلت مشكلة في البحث، حاول تاني");
                    return;
                  }
                  if (!req) {
                    setFound(null);
                    toast.error("مش لاقي طلب بالرقم ده");
                    return;
                  }
                  setFound(req);
                  setRateStars(req.rating?.stars || 5);
                  setRateComment(req.rating?.comment || "");
                  // Reset edit state
                  if (req.dateISO) setEditDate(new Date(req.dateISO));
                  setEditSlot(req.slot || "");
                }}
              >
                <div className="grid gap-2 flex-1">
                  <label className="text-sm font-medium">رقم المتابعة</label>
                  <Input value={code} onChange={(e) => setCode(e.target.value)} placeholder="مثال: 123456" inputMode="numeric" />
                  <div className="text-xs text-muted-foreground">{hint}</div>
                </div>
                <Button type="submit" className="bg-primary text-primary-foreground hover:bg-primary/90">
                  بحث
                </Button>
              </form>

              {found ? (
                <div className="mt-6 grid gap-3">
                  <div className="flex items-center justify-between gap-2">
                    <div className="text-sm text-muted-foreground">الحالة</div>
                    {statusBadge(found.status)}
                  </div>

                  {/* Actions for active requests */}
                  {["new", "contacted"].includes(found.status) && (
                    <div className="flex flex-wrap gap-2 rounded-xl border border-dashed p-3">
                      <div className="w-full text-xs font-semibold text-muted-foreground">إدارة الطلب:</div>
                      
                      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
                        <DialogTrigger asChild>
                          <Button variant="outline" size="sm">تعديل الميعاد</Button>
                        </DialogTrigger>
                        <DialogContent>
                          <DialogHeader>
                            <DialogTitle>تعديل ميعاد الزيارة</DialogTitle>
                          </DialogHeader>
                          <div className="grid gap-4 py-4">
                            <div className="grid gap-2">
                              <label className="text-sm font-medium">التاريخ الجديد</label>
                              <Popover>
                                <PopoverTrigger asChild>
                                  <Button
                                    variant="outline"
                                    className={cn("justify-between text-left font-normal", !editDate && "text-muted-foreground")}
                                  >
                                    {editDate ? format(editDate, "yyyy-MM-dd") : "اختار التاريخ"}
                                    <Clock className="h-4 w-4 opacity-50" />
                                  </Button>
                                </PopoverTrigger>
                                <PopoverContent className="w-auto p-0">
                                  <Calendar
                                    mode="single"
                                    selected={editDate || undefined}
                                    onSelect={(d) => setEditDate(d || null)}
                                    disabled={(d) => d < new Date(new Date().setHours(0, 0, 0, 0))}
                                    initialFocus
                                  />
                                </PopoverContent>
                              </Popover>
                            </div>
                            <div className="grid gap-2">
                              <label className="text-sm font-medium">الوقت المناسب</label>
                              <Select value={editSlot} onValueChange={setEditSlot}>
                                <SelectTrigger>
                                  <SelectValue placeholder="اختار الوقت" />
                                </SelectTrigger>
                                <SelectContent>
                                  {timeSlots.map((t) => (
                                    <SelectItem key={t} value={t}>{t}</SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                            </div>
                            <Button onClick={saveReschedule}>حفظ التغييرات</Button>
                          </div>
                        </DialogContent>
                      </Dialog>

                      <Button variant="destructive" size="sm" onClick={cancelRequest}>إلغاء الطلب</Button>
                    </div>
                  )}

                  <div className="rounded-2xl border bg-secondary/25 p-4">
                    <div className="text-sm font-semibold">تفاصيل الطلب</div>
                    <div className="mt-2 text-sm text-muted-foreground leading-7">
                      <div>
                        <span className="text-foreground/80">الخدمة:</span> {found.service}
                      </div>
                      <div>
                        <span className="text-foreground/80">المنطقة:</span> {found.city}
                      </div>
                      <div>
                        <span className="text-foreground/80">المعاد:</span> {found.dateISO} ({found.slot})
                      </div>
                      <div>
                        <span className="text-foreground/80">الدفع:</span> {found.payment}
                      </div>
                    </div>
                  </div>

                  <div className="rounded-2xl border bg-card p-4">
                    <div className="text-sm font-semibold">الصنايعي المُعيّن</div>
                    {found.assignedProSnapshot ? (
                      <div className="mt-2 text-sm text-muted-foreground leading-7">
                        <div>
                          <span className="text-foreground/80">الاسم:</span> {found.assignedProSnapshot.name}
                        </div>
                        <div>
                          <span className="text-foreground/80">الموبايل:</span> {found.assignedProSnapshot.phone}
                        </div>
                        <div>
                          <span className="text-foreground/80">التخصص:</span> {found.assignedProSnapshot.trade}
                        </div>
                        <div className="mt-3">
                          <a 
                            href={`https://wa.me/${found.assignedProSnapshot.phone.replace(/\D/g, '').startsWith('20') ? found.assignedProSnapshot.phone.replace(/\D/g, '') : '20' + found.assignedProSnapshot.phone.replace(/\D/g, '')}?text=${encodeURIComponent("مرحبًا، أنا بكلمك بخصوص طلب Sanay3i رقم " + found.trackingCode)}`} 
                            target="_blank" 
                            rel="noreferrer"
                          >
                            <Button size="sm" variant="outline" className="gap-2">
                              <MessageCircle className="h-4 w-4" /> تواصل واتساب
                            </Button>
                          </a>
                        </div>
                      </div>
                    ) : (
                      <div className="mt-2 text-sm text-muted-foreground">لسه ما تمش تعيين صنايعي للطلب.</div>
                    )}
                  </div>

                  {found.invoiceStatus === "approved" && (
                    <div className="rounded-2xl border-2 border-primary/30 bg-primary/5 p-4">
                      <div className="text-sm font-semibold flex items-center gap-2">
                        🧾 فاتورة الخدمة جاهزة
                      </div>
                      <p className="mt-1 text-sm text-muted-foreground">
                        الفاتورة الرسمية بتفاصيل الخدمة والمبلغ بقت جاهزة، تقدر تشوفها وتطبعها.
                      </p>
                      <div className="mt-3">
                        <Button
                          size="sm"
                          className="gap-2 bg-primary text-primary-foreground hover:bg-primary/90"
                          onClick={() => window.open(`#/invoice/${found.trackingCode}`, "_blank")}
                        >
                          عرض / طباعة الفاتورة
                        </Button>
                      </div>
                    </div>
                  )}

                  {/* تقييم الصنايعي */}
                  {found.assignedProSnapshot ? (
                    <div className="rounded-2xl border bg-secondary/20 p-4">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <div className="text-sm font-semibold">قيّم الخدمة</div>
                        {found.rating ? (
                          <Badge variant="secondary">تم التقييم</Badge>
                        ) : (
                          <Badge className="bg-accent text-accent-foreground">مفتوح</Badge>
                        )}
                      </div>

                      <div className="mt-3 grid gap-3">
                        <div className="grid gap-2">
                          <div className="text-sm text-muted-foreground">عدد النجوم</div>
                          <div className="flex flex-wrap gap-2">
                            {[1, 2, 3, 4, 5].map((n) => (
                              <Button
                                key={n}
                                type="button"
                                variant={rateStars === n ? "default" : "outline"}
                                onClick={() => setRateStars(n)}
                              >
                                {n}
                              </Button>
                            ))}
                          </div>
                        </div>

                        <div className="grid gap-2">
                          <label className="text-sm font-medium">تعليق (اختياري)</label>
                          <Textarea
                            rows={3}
                            placeholder="قولنا رأيك في جودة الشغل والتعامل…"
                            value={rateComment}
                            onChange={(e) => setRateComment(e.target.value)}
                          />
                        </div>

                        <div className="flex flex-wrap gap-2">
                          <Button
                            type="button"
                            className="bg-primary text-primary-foreground hover:bg-primary/90"
                            onClick={() => {
                              const stars = Math.min(5, Math.max(1, Number(rateStars || 5)));
                              const comment = String(rateComment || "").trim();
                              saveRating(stars, comment);
                            }}
                          >
                            حفظ التقييم
                          </Button>

                          {found.rating ? (
                            <Button
                              type="button"
                              variant="outline"
                              onClick={removeRating}
                            >
                              حذف التقييم
                            </Button>
                          ) : null}
                        </div>

                        {found.rating ? (
                          <div className="text-xs text-muted-foreground">
                            آخر تقييم: {found.rating.stars} / 5
                            {found.rating.ratedAt ? ` • ${new Date(found.rating.ratedAt).toLocaleString()}` : ""}
                          </div>
                        ) : null}
                      </div>
                    </div>
                  ) : null}

                  <div className="text-xs text-muted-foreground">
                    بياناتك محفوظة على السيرفر — تقدر تتابع الطلب من أي جهاز بنفس رقم المتابعة.
                  </div>
                </div>
              ) : null}
            </CardContent>
          </Card>
        </div>
      </section>
    </SiteLayout>
  );
}
