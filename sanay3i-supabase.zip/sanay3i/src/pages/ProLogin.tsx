/*
  Sanay3i — ProLogin
  - Pro logs in with their access code via the pro_login() RPC
*/

import { useState } from "react";
import { useLocation } from "wouter";

import SiteLayout from "@/components/SiteLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import { sbRpc } from "@/lib/supabase";

export default function ProLogin() {
  const [, setLocation] = useLocation();
  const [code, setCode] = useState("");

  return (
    <SiteLayout>
      <section className="container-sanay3i section-sanay3i">
        <div className="mx-auto w-full max-w-xl">
          <h1 className="font-display text-3xl font-bold md:text-4xl">دخول الصنايعي</h1>
          <p className="mt-2 text-muted-foreground leading-7">
            بعد ما الإدارة تقبل طلبك، هتديك كود دخول. اكتبه هنا علشان تشوف الطلبات اللي متعيّنة عليك.
          </p>

          <Card className="mt-6 overflow-hidden card-elevated">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">كود الدخول</CardTitle>
            </CardHeader>
            <CardContent>
              <form
                className="grid gap-4"
                onSubmit={async (e) => {
                  e.preventDefault();
                  let acc: any = null;
                  try {
                    const rows = await sbRpc<any[]>("pro_login", { p_code: code.trim() });
                    acc = rows?.[0] || null;
                  } catch (err) {
                    console.error(err);
                    toast.error("حصلت مشكلة، حاول تاني");
                    return;
                  }
                  if (!acc) {
                    toast.error("الكود غير صحيح");
                    return;
                  }
                  localStorage.setItem("sanay3i_pro_authed", "1");
                  localStorage.setItem("sanay3i_pro_authed_id", acc.id);
                  localStorage.setItem(
                    "sanay3i_pro_me",
                    JSON.stringify({ id: acc.id, name: acc.name, phone: acc.phone, trade: acc.trade, city: acc.city })
                  );
                  toast.success("تم تسجيل الدخول");
                  setLocation("/pro/dashboard");
                }}
              >
                <div className="grid gap-2">
                  <label className="text-sm font-medium">كود الدخول</label>
                  <Input value={code} onChange={(e) => setCode(e.target.value)} placeholder="مثال: PRO-1234" />
                </div>
                <Button type="submit" className="bg-primary text-primary-foreground hover:bg-primary/90">
                  دخول
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>
      </section>
    </SiteLayout>
  );
}
