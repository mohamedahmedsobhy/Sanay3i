/*
  Sanay3i — AdminLogin
  - Real Supabase Auth (email/password). The session token is what
    unlocks admin-only rows via RLS — see the "secure_rls_and_public_rpcs"
    migration for the server side of this.
*/

import { useState } from "react";
import { useLocation } from "wouter";

import SiteLayout from "@/components/SiteLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import { adminSignIn } from "@/lib/supabase";

export default function AdminLogin() {
  const [, setLocation] = useLocation();

  const [email, setEmail] = useState("");
  const [pass, setPass] = useState("");
  const [loading, setLoading] = useState(false);

  return (
    <SiteLayout>
      <section className="container-sanay3i section-sanay3i">
        <div className="mx-auto w-full max-w-xl">
          <h1 className="font-display text-3xl font-bold md:text-4xl">داشبورد الإدارة</h1>
          <p className="mt-2 text-muted-foreground leading-7">
            تسجيل دخول الإدارة — محمي بحساب حقيقي على Supabase Auth.
          </p>

          <Card className="mt-6 overflow-hidden card-elevated">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">تسجيل الدخول</CardTitle>
            </CardHeader>
            <CardContent>
              <form
                className="grid gap-4"
                onSubmit={async (e) => {
                  e.preventDefault();
                  setLoading(true);
                  try {
                    await adminSignIn(email.trim(), pass);
                    toast.success("تم تسجيل الدخول");
                    setLocation("/admin/dashboard");
                  } catch (err) {
                    console.error(err);
                    toast.error("بيانات الدخول غير صحيحة");
                  } finally {
                    setLoading(false);
                  }
                }}
              >
                <div className="grid gap-2">
                  <label className="text-sm font-medium">الإيميل</label>
                  <Input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="admin@" inputMode="email" />
                </div>
                <div className="grid gap-2">
                  <label className="text-sm font-medium">الباس</label>
                  <Input value={pass} onChange={(e) => setPass(e.target.value)} type="password" placeholder="••••" />
                </div>

                <Button type="submit" disabled={loading} className="bg-primary text-primary-foreground hover:bg-primary/90">
                  {loading ? "جاري الدخول..." : "دخول"}
                </Button>

              </form>
            </CardContent>
          </Card>
        </div>
      </section>
    </SiteLayout>
  );
}
