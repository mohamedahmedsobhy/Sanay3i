/*
  Sanay3i — How It Works Page
*/

import SiteLayout from "@/components/SiteLayout";
import PageHeader from "@/components/PageHeader";
import { BadgeCheck, Clock, Phone, ShieldCheck, Sparkles } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";

export default function HowPage() {
  return (
    <SiteLayout>
      <PageHeader title="ازاي بنشتغل" subtitle="تجربة حجز بسيطة — واضحة من الأول للآخر." />
      <section className="container-sanay3i section-sanay3i pt-0">
        <div>
          <h1 className="font-display text-3xl font-bold md:text-5xl">ازاي بنشتغل</h1>
          <p className="mt-2 text-muted-foreground">تجربة حجز بسيطة — واضحة من الأول للآخر.</p>
        </div>

        <div className="mt-8 grid gap-6 md:grid-cols-12 md:items-start">
          <div className="md:col-span-5">
            <div className="rounded-3xl border bg-card p-5 shadow-sm card-elevated">
              <div className="flex items-center gap-3">
                <div className="grid h-12 w-12 place-items-center rounded-2xl bg-primary text-primary-foreground">
                  <Phone className="h-5 w-5" />
                </div>
                <div>
                  <div className="text-sm font-semibold">تأكيد سريع</div>
                  <div className="text-xs text-muted-foreground">بنرجعلك تأكيد للميعاد والتفاصيل</div>
                </div>
              </div>
              <Separator className="my-4" />
              <div className="flex items-center gap-3">
                <div className="grid h-12 w-12 place-items-center rounded-2xl bg-secondary text-secondary-foreground">
                  <ShieldCheck className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <div className="text-sm font-semibold">متابعة جودة</div>
                  <div className="text-xs text-muted-foreground">بعد الزيارة بنتأكد إن كل حاجة تمام</div>
                </div>
              </div>
            </div>
          </div>

          <div className="md:col-span-7">
            <div className="grid gap-4 sm:grid-cols-2">
              {[{
                step: "01",
                title: "ابعت طلب",
                desc: "اختار الخدمة والمنطقة وحدد الميعاد وطريقة الدفع.",
                icon: Sparkles,
              },{
                step: "02",
                title: "نأكد الميعاد",
                desc: "تأكيد سريع للتفاصيل قبل أي زيارة.",
                icon: BadgeCheck,
              },{
                step: "03",
                title: "زيارة وتنفيذ",
                desc: "الصنايعي يوصل في الميعاد ويبدأ الشغل.",
                icon: Clock,
              },{
                step: "04",
                title: "متابعة بعد الزيارة",
                desc: "لو في أي ملاحظة… بنرجع نتابع فورًا.",
                icon: ShieldCheck,
              }].map((it) => (
                <Card key={it.step} className="relative overflow-hidden">
                  <div className="absolute -left-10 -top-10 h-28 w-28 rounded-full bg-primary/10 blur-2xl" />
                  <CardHeader className="pb-2">
                    <div className="flex items-center justify-between">
                      <div className="text-xs text-muted-foreground">الخطوة</div>
                      <div className="font-display text-2xl font-bold text-primary">{it.step}</div>
                    </div>
                    <CardTitle className="text-lg flex items-center gap-2">
                      <it.icon className="h-4 w-4 text-primary" />
                      {it.title}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="text-sm leading-6 text-muted-foreground">{it.desc}</CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </section>
    </SiteLayout>
  );
}
