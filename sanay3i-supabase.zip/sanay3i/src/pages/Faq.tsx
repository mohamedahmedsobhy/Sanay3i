/*
  Sanay3i — FAQ Page
*/

import SiteLayout from "@/components/SiteLayout";
import PageHeader from "@/components/PageHeader";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

export default function FaqPage() {
  return (
    <SiteLayout>
      <PageHeader title="الأسئلة الشائعة" subtitle="مختصر مفيد قبل ما تطلب." />
      <section className="container-sanay3i section-sanay3i pt-0">
        <div>
          <h1 className="font-display text-3xl font-bold md:text-5xl">الأسئلة الشائعة</h1>
          <p className="mt-2 text-muted-foreground">مختصر مفيد قبل ما تطلب.</p>
        </div>

        <div className="mt-8 max-w-3xl rounded-3xl border bg-card p-4 md:p-5 card-elevated">
          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="a">
              <AccordionTrigger>إزاي الحجز بيتم؟</AccordionTrigger>
              <AccordionContent>
                بتكتب بياناتك وتختار الخدمة والمنطقة وتحدد الميعاد وطريقة الدفع، وبعدين تضغط إرسال — هيظهر لك رقم متابعة تقدر تراجع بيه حالة الطلب.
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="b">
              <AccordionTrigger>طرق الدفع المتاحة إيه؟</AccordionTrigger>
              <AccordionContent>
                تقدر تختار طريقة الدفع أثناء الطلب (كاش / فودافون كاش / إنستاباي / تحويل بنكي… حسب الأنسب).
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="c">
              <AccordionTrigger>الخدمات الموجودة هنا حقيقية؟</AccordionTrigger>
              <AccordionContent>
                أيوه — دي فئات خدمات منزلية موجودة فعلاً (سباكة/كهرباء/دهان/نجارة/تكييف/تنضيف). الاختلاف بيكون في التوفر حسب منطقتك.
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="d">
              <AccordionTrigger>هل في مواعيد عاجلة؟</AccordionTrigger>
              <AccordionContent>
                حسب التوفر في منطقتك. ابعت طلبك من الموقع وهتقدر تتابع حالته برقم المتابعة.
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </div>
      </section>
    </SiteLayout>
  );
}
