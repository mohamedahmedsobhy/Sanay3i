/*
  Sanay3i — PrintInvoice
  - Public page (reachable by tracking code, no login needed) that shows
    the approved service invoice for a booking, with a print button.
  - Uses the anon-safe track_booking() RPC, same one TrackRequest.tsx uses,
    so no direct table access is required.
*/

import { useEffect, useState } from "react";
import { useRoute } from "wouter";
import { Printer } from "lucide-react";
import { Button } from "@/components/ui/button";
import { sbRpc } from "@/lib/supabase";
import logoWordmark2x from "@/assets/logo-wordmark-tight-2x.png";
import stampOfficial from "@/assets/stamp-official.png";

type Invoice = {
  trackingCode: string;
  createdAt: string;
  customerName: string;
  customerPhone: string;
  city: string;
  address?: string;
  service: string;
  proName?: string;
  dateISO: string;
  slot: string;
  payment: string;
  invoiceNotes?: string;
  materialsCost: number;
  laborCost: number;
  transportCost: number;
  discount: number;
  status?: string;
};

function fromRow(row: any): Invoice {
  return {
    trackingCode: row.tracking_code,
    createdAt: row.created_at,
    customerName: row.customer_name,
    customerPhone: row.customer_phone,
    city: row.city,
    address: row.address,
    service: row.service,
    proName: row.pro_name,
    dateISO: row.date_iso,
    slot: row.slot,
    payment: row.payment,
    invoiceNotes: row.invoice_notes,
    materialsCost: Number(row.invoice_materials_cost) || 0,
    laborCost: Number(row.invoice_labor_cost) || 0,
    transportCost: Number(row.invoice_transport_cost) || 0,
    discount: Number(row.invoice_discount) || 0,
    status: row.invoice_status,
  };
}

function Row({ label, value }: { label: string; value?: string }) {
  return (
    <div className="flex items-baseline gap-2 border-b border-gray-200 pb-1">
      <span className="shrink-0 text-sm font-bold text-[#003845]">{label}</span>
      <span className="flex-1 text-sm text-gray-800">{value || "—"}</span>
    </div>
  );
}

function PriceRow({ label, value, bold }: { label: string; value: number; bold?: boolean }) {
  return (
    <div className={`flex items-center justify-between px-3 py-2 text-sm ${bold ? "bg-[#003845] text-white font-bold" : "text-gray-800"}`}>
      <span>{label}</span>
      <span>{value.toLocaleString("ar-EG")} ج.م</span>
    </div>
  );
}

export default function PrintInvoice() {
  const [, params] = useRoute("/invoice/:code");
  const [inv, setInv] = useState<Invoice | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!params?.code) return;
    (async () => {
      setLoading(true);
      setError("");
      try {
        const rows = await sbRpc<any[]>("track_booking", { p_code: params.code });
        if (!rows || !rows.length) {
          setError("الطلب غير موجود.");
          return;
        }
        setInv(fromRow(rows[0]));
      } catch (err) {
        console.error(err);
        setError("حصلت مشكلة في تحميل الفاتورة.");
      } finally {
        setLoading(false);
      }
    })();
  }, [params?.code]);

  if (loading) return <div className="p-10 text-center text-gray-500">جاري التحميل...</div>;
  if (error || !inv) return <div className="p-10 text-center text-red-600">{error || "حصلت مشكلة."}</div>;

  if (inv.status !== "approved") {
    return (
      <div dir="rtl" className="mx-auto max-w-lg p-10 text-center">
        <img src={logoWordmark2x} alt="Sanay3i" className="mx-auto h-9" />
        <p className="mt-6 text-gray-600">
          الفاتورة الخاصة بالطلب <span className="font-bold">{inv.trackingCode}</span> لسه ماوصلتش من الصنايعي أو لسه قيد مراجعة الإدارة. تابع معانا وهتوصلك فور اعتمادها.
        </p>
      </div>
    );
  }

  const total = inv.materialsCost + inv.laborCost + inv.transportCost - inv.discount;

  return (
    <div dir="rtl" className="mx-auto min-h-screen max-w-3xl bg-white px-7 py-5 text-black">
      <style>{`
        @media print {
          .no-print { display: none !important; }
          @page { size: A4; margin: 12mm; }
          body { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
        }
      `}</style>

      <div className="no-print mb-6 flex justify-center">
        <Button onClick={() => window.print()} className="gap-2 bg-[#003845] hover:bg-[#0F4E5C]">
          <Printer className="h-4 w-4" />
          طباعة / حفظ PDF
        </Button>
      </div>

      <div className="flex flex-col items-center">
        <img src={logoWordmark2x} alt="Sanay3i" className="h-10" />
        <span className="mt-1 text-xs text-gray-500">الصنايعي المضمون في إيدك</span>
      </div>
      <div className="mt-2 border-b-4 border-[#F6623D]" />
      <div className="border-b border-[#003845]" />

      <h1 className="mt-2 text-center text-2xl font-bold text-[#003845]">فاتورة خدمة</h1>
      <p className="mt-1 text-center text-sm text-gray-500">إيصال استلام خدمة من صنايعي Sanay3i معتمد</p>

      <div className="mt-4 flex justify-between text-sm">
        <span><span className="font-bold text-[#003845]">رقم الفاتورة / التتبع: </span>{inv.trackingCode}</span>
        <span><span className="font-bold text-[#003845]">التاريخ: </span>{new Date(inv.createdAt).toLocaleDateString("ar-EG")}</span>
      </div>

      <h2 className="mt-5 border-b-2 border-[#F6623D] pb-1 text-lg font-bold text-[#003845]">بيانات العميل</h2>
      <div className="mt-3 space-y-2.5">
        <Row label="اسم العميل" value={inv.customerName} />
        <div className="grid grid-cols-2 gap-5">
          <Row label="رقم الهاتف" value={inv.customerPhone} />
          <Row label="المدينة / المنطقة" value={inv.city} />
        </div>
        {inv.address && <Row label="العنوان" value={inv.address} />}
      </div>

      <h2 className="mt-5 border-b-2 border-[#F6623D] pb-1 text-lg font-bold text-[#003845]">تفاصيل الخدمة</h2>
      <div className="mt-3 space-y-2.5">
        <div className="grid grid-cols-2 gap-5">
          <Row label="نوع الخدمة" value={inv.service} />
          <Row label="اسم الصنايعي" value={inv.proName} />
        </div>
        <div className="grid grid-cols-2 gap-5">
          <Row label="تاريخ التنفيذ" value={inv.dateISO} />
          <Row label="الميعاد" value={inv.slot} />
        </div>
        {inv.invoiceNotes && <Row label="وصف الأعمال" value={inv.invoiceNotes} />}
      </div>

      <h2 className="mt-5 border-b-2 border-[#F6623D] pb-1 text-lg font-bold text-[#003845]">تفاصيل المبلغ</h2>
      <div className="mt-3 overflow-hidden rounded-md border border-gray-300 divide-y divide-gray-200">
        <PriceRow label="قيمة الخامات" value={inv.materialsCost} />
        <PriceRow label="أجرة الصنايعي" value={inv.laborCost} />
        <PriceRow label="مصاريف انتقال" value={inv.transportCost} />
        {inv.discount > 0 && <PriceRow label="خصم" value={-inv.discount} />}
        <PriceRow label="الإجمالي المستحق" value={total} bold />
      </div>

      <p className="mt-3 text-sm">
        <span className="font-bold text-[#003845]">طريقة الدفع: </span>{inv.payment || "—"}
      </p>

      <div className="mt-6 flex items-center justify-center gap-3">
        <img src={stampOfficial} alt="Sanay3i Official Stamp" className="h-16 w-16 object-contain opacity-90" />
      </div>

      <div className="mt-4 border-t pt-2 text-center text-xs italic text-gray-500">
        شكرًا لثقتك في Sanay3i — للاستفسار والدعم: تواصل مع فريق خدمة العملاء
      </div>
    </div>
  );
}
