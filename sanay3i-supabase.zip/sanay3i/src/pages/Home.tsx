/*
  Sanay3i — Home (Landing)
  - Multi-page website: landing only
*/

import { motion } from "framer-motion";
import { ShieldCheck, CalendarCheck, Search, Wrench, Shield, ArrowUpRight, Github, Linkedin, Twitter, Code, Palette } from "lucide-react";
import SiteLayout from "@/components/SiteLayout";
import heroImg from "@/assets/sanay3i-hero.jpeg";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

import ahmedEbrahimAvatar from "@/assets/team-ahmed-ebrahim-avatar-256.jpg";
import mohamedAhmedAvatar from "@/assets/team-mohamed-ahmed-avatar-256.jpg";

export default function Home() {
  return (
    <SiteLayout>
      {/* HERO */}
      <section className="grain relative overflow-hidden">
        <div className="absolute inset-0 -z-10 bg-[radial-gradient(1200px_circle_at_20%_0%,oklch(0.98_0.03_85),transparent_55%),radial-gradient(900px_circle_at_90%_20%,oklch(0.93_0.04_60),transparent_55%)]" />

        <div className="container-sanay3i section-sanay3i pt-10 md:pt-12">
          <div className="grid items-center gap-10 md:grid-cols-12">
            <motion.div
              initial={{ opacity: 0, x: 18 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.65, ease: "easeOut" }}
              className="order-2 md:order-1 md:col-span-6"
            >
              <div className="inline-flex items-center gap-2 rounded-full border bg-card px-3 py-1 text-xs text-muted-foreground shadow-sm">
                <ShieldCheck className="h-4 w-4 text-primary" />
                متابعة جودة + مواعيد واضحة
              </div>

              <h1 className="font-display mt-4 text-[2.75rem] font-bold leading-[1.08] md:text-6xl">
                اطلب صنايعي <span className="text-primary mr-2">من غير دوشة</span>
              </h1>

              <p className="mt-4 text-base leading-7 text-muted-foreground md:text-lg">
                Sanay3i بيقدملك خدمات البيت الأساسية (سباكة، كهرباء، دهان، نجارة…)
                بطريقة واضحة: بتحدد طلبك، تبعته، وبيوصلك رقم متابعة تقدر تراجع بيه حالة الطلب في أي وقت.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, ease: "easeOut", delay: 0.1 }}
              className="order-1 md:order-2 md:col-span-6"
            >
              <div className="relative overflow-hidden rounded-[2rem] border bg-card card-elevated">
                <div className="absolute inset-0 bg-[linear-gradient(135deg,transparent,oklch(0.30_0.085_210)/10,transparent)]" />
                <img src={heroImg} alt="Sanay3i hero" className="h-[260px] w-full object-cover md:h-[420px]" />
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* CORE ACTIONS SECTION */}
      <section className="py-12">
        <div className="container-sanay3i">
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {/* Booking Card */}
            <a href="#/booking" className="block group">
              <Card className="h-full border-2 border-primary/10 bg-card hover:border-primary hover:shadow-lg transition-all duration-300 card-elevated">
                <CardContent className="p-6 flex flex-col items-center text-center">
                  <div className="h-16 w-16 rounded-2xl bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
                    <CalendarCheck className="h-8 w-8 text-primary group-hover:text-primary-foreground" />
                  </div>
                  <h3 className="font-display text-xl font-bold mb-2">احجز زيارة</h3>
                  <p className="text-sm text-muted-foreground">احجز صنايعي شاطر في خطوات بسيطة.</p>
                </CardContent>
              </Card>
            </a>

            {/* Track Order Card */}
            <a href="#/track" className="block group">
              <Card className="h-full border-2 border-primary/10 bg-card hover:border-primary hover:shadow-lg transition-all duration-300 card-elevated">
                <CardContent className="p-6 flex flex-col items-center text-center">
                  <div className="h-16 w-16 rounded-2xl bg-secondary flex items-center justify-center mb-4 group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
                    <Search className="h-8 w-8 text-primary group-hover:text-primary-foreground" />
                  </div>
                  <h3 className="font-display text-xl font-bold mb-2">متابعة الطلب</h3>
                  <p className="text-sm text-muted-foreground">شوف طلبك وصل لفين برقم المتابعة.</p>
                </CardContent>
              </Card>
            </a>

            {/* Pro Dashboard Card */}
            <a href="#/pro/dashboard" className="block group">
              <Card className="h-full border-2 border-primary/10 bg-card hover:border-primary hover:shadow-lg transition-all duration-300 card-elevated">
                <CardContent className="p-6 flex flex-col items-center text-center">
                  <div className="h-16 w-16 rounded-2xl bg-accent/10 flex items-center justify-center mb-4 group-hover:bg-accent group-hover:text-accent-foreground transition-colors">
                    <Wrench className="h-8 w-8 text-accent group-hover:text-accent-foreground" />
                  </div>
                  <h3 className="font-display text-xl font-bold mb-2">لوحة الصنايعي</h3>
                  <p className="text-sm text-muted-foreground">للصنايعية المسجلين لإدارة شغلهم.</p>
                </CardContent>
              </Card>
            </a>

            {/* Admin Dashboard Card */}
            <a href="#/admin" className="block group">
              <Card className="h-full border-2 border-primary/10 bg-card hover:border-primary hover:shadow-lg transition-all duration-300 card-elevated">
                <CardContent className="p-6 flex flex-col items-center text-center">
                  <div className="h-16 w-16 rounded-2xl bg-muted flex items-center justify-center mb-4 group-hover:bg-foreground group-hover:text-background transition-colors">
                    <Shield className="h-8 w-8 text-foreground group-hover:text-background" />
                  </div>
                  <h3 className="font-display text-xl font-bold mb-2">الإدارة</h3>
                  <p className="text-sm text-muted-foreground">لوحة التحكم للمشرفين والمسؤولين.</p>
                </CardContent>
              </Card>
            </a>
          </div>
        </div>
      </section>

      {/* Emergency Section (Simplified) */}
      <section className="bg-primary py-20">
        <div className="container-sanay3i">
          <div className="max-w-3xl mx-auto">
            <Card className="bg-primary-foreground/10 border-primary-foreground/20 text-primary-foreground p-10 card-elevated text-center">
              <h2 className="font-display text-3xl font-bold md:text-4xl mb-6">خدمات الطوارئ 24/7</h2>
              <p className="text-primary-foreground/90 leading-8 text-xl mb-8">
                ماس كهربائي؟ تسريب مياه مفاجئ؟ Sanay3i بيوفر خدمة طوارئ شغالة طول اليوم عشان نلحقك في الوقت الصعب.
              </p>
              <Button size="lg" variant="secondary" className="font-bold text-lg px-8 py-6 h-auto w-full sm:w-auto">
                اطلب طوارئ الآن
              </Button>
            </Card>
          </div>
        </div>
      </section>

      {/* Team Section (Redesigned) */}
      <section className="bg-gradient-to-b from-background to-secondary/30 py-24 border-t border-border/50">
        <div className="container-sanay3i">
          <div className="text-center mb-16">
            <h2 className="font-display text-4xl font-bold text-foreground">فريق العمل</h2>
            <p className="mt-3 text-lg text-muted-foreground">العقول المبدعة وراء Sanay3i</p>
          </div>
          
          <div className="flex flex-col md:flex-row justify-center items-center gap-10 max-w-5xl mx-auto">
            {[{
              name: "MOHAMED AHMED",
              role: "Web Developer",
              desc: "المطور المسؤول عن بناء وتطوير المنصة بأحدث التقنيات لضمان أفضل أداء.",
              img: mohamedAhmedAvatar,
              initials: "MA",
              icon: Code
            },{
              name: "AHMED EBRAHEM",
              role: "Designer",
              desc: "المصمم المسؤول عن تجربة المستخدم والواجهة البصرية الجذابة والسهلة.",
              img: ahmedEbrahimAvatar,
              initials: "AE",
              icon: Palette
            }].map((m, i) => (
              <motion.div 
                key={m.name}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="group relative w-full max-w-md"
              >
                <div className="absolute inset-0 bg-primary/5 rounded-[2rem] rotate-3 group-hover:rotate-6 transition-transform duration-300" />
                <Card className="relative overflow-hidden border-2 border-border/50 bg-card/80 backdrop-blur card-elevated h-full hover:border-primary/20 transition-colors">
                  <div className="absolute top-0 right-0 h-32 w-32 bg-primary/10 blur-[60px] rounded-full -translate-y-1/2 translate-x-1/2" />
                  
                  <CardContent className="flex flex-col items-center text-center p-8 pt-10">
                    <div className="relative mb-6">
                      <div className="absolute inset-0 rounded-full bg-primary/20 blur-md animate-pulse" />
                      <Avatar className="h-32 w-32 border-4 border-background shadow-xl relative z-10">
                        <AvatarImage src={m.img} alt={m.name} className="object-cover" />
                        <AvatarFallback className="text-2xl font-bold">{m.initials}</AvatarFallback>
                      </Avatar>
                      <div className="absolute bottom-1 right-1 h-8 w-8 bg-background rounded-full flex items-center justify-center border shadow-sm z-20 text-primary">
                        <m.icon className="h-4 w-4" />
                      </div>
                    </div>
                    
                    <h3 className="font-display text-2xl font-bold mb-1">{m.name}</h3>
                    <div className="text-sm font-bold text-primary uppercase tracking-wider mb-4 px-3 py-1 bg-primary/10 rounded-full">
                      {m.role}
                    </div>
                    
                    <p className="text-muted-foreground leading-relaxed mb-6">
                      {m.desc}
                    </p>
                    
                    <div className="flex gap-3 mt-auto opacity-60 hover:opacity-100 transition-opacity">
                      {/* Placeholder Social Icons */}
                      <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
                        <Linkedin className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
                        <Github className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </SiteLayout>
  );
}
