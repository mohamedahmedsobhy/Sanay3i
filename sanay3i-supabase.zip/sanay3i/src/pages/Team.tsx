/*
  Sanay3i — Team Page
*/

import SiteLayout from "@/components/SiteLayout";
import PageHeader from "@/components/PageHeader";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

import ahmedEbrahimAvatar from "@/assets/team-ahmed-ebrahim-avatar-256.jpg";
import mohamedAhmedAvatar from "@/assets/team-mohamed-ahmed-avatar-256.jpg";

export default function TeamPage() {
  return (
    <SiteLayout>
      <PageHeader title="فريق المشروع" subtitle="الناس اللي اشتغلوا على Sanay3i." />
      <section className="container-sanay3i section-sanay3i pt-0">
        <div>
          <h1 className="font-display text-3xl font-bold md:text-5xl">فريق المشروع</h1>
          <p className="mt-2 text-muted-foreground">صنّاع Sanay3i.</p>
        </div>

        <div className="mt-8 grid gap-4 sm:grid-cols-2">
          {[{
            name: "MOHAMED AHMED",
            role: "Web Developer",
            img: mohamedAhmedAvatar,
            initials: "MA",
          },{
            name: "AHMED EBRAHEM",
            role: "Designer",
            img: ahmedEbrahimAvatar,
            initials: "AE",
          }].map((m) => (
            <Card key={m.name} className="overflow-hidden card-elevated">
              <CardContent className="flex items-center gap-5 p-6">
                <Avatar className="h-18 w-18 border">
                  <AvatarImage src={m.img} alt={m.name} />
                  <AvatarFallback>{m.initials}</AvatarFallback>
                </Avatar>
                <div className="min-w-0">
                  <div className="font-display text-lg font-bold leading-tight">{m.name}</div>
                  <div className="text-sm text-muted-foreground">{m.role}</div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-6 text-xs text-muted-foreground">
          تم تنفيذ المشروع بواسطة AHMED EBRAHEM و MOHAMED AHMED.
        </div>
      </section>
    </SiteLayout>
  );
}
