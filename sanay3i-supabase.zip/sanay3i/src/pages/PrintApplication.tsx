/*
  Sanay3i — PrintApplication
  - Admin-only printable version of a craftsman's application: pre-filled
    with their submitted data and photos (selfie + ID front/back).
  - Meant to be printed (or saved as PDF) from the browser before the
    admin approves the craftsman, so there's a signed physical/PDF copy
    with a wet signature + stamp.
  - Reachable from AdminDashboard's "طباعة الاستمارة" button.
*/

import { useEffect, useState } from "react";
import { useRoute } from "wouter";
import { Printer } from "lucide-react";
import { Button } from "@/components/ui/button";
import { sbSelect } from "@/lib/supabase";
import logoWordmark2x from "@/assets/logo-wordmark-tight-2x.png";
import stampOfficial from "@/assets/stamp-official.png";

type ProApplication = {
  id: string;
  createdAt: string;
  name: string;
  phone: string;
  trade: string;
  city: string;
  experienceYears: string;
  nationalId?: string;
  idFrontDataUrl?: string;
  idBackDataUrl?: string;
  selfieDataUrl?: string;
};

function fromRow(row: any): ProApplication {
  return {
    id: row.id,
    createdAt: row.created_at,
    name: row.name,
    phone: row.phone,
    trade: row.trade,
    city: row.city,
    experienceYears: row.experience_years,
    nationalId: row.national_id,
    idFrontDataUrl: row.id_front_data_url,
    idBackDataUrl: row.id_back_data_url,
    selfieDataUrl: row.selfie_data_url,
  };
}

const COMMITMENTS = [
  "ألتزم بتقديم الخدمة بجودة عالية ومهنية وفقًا لأصول الحرفة.",
  "ألتزم بالمواعيد المتفق عليها مع العميل عن طريق منصّة Sanay3i، وإبلاغ الإدارة فورًا عند أي تأخير.",
  "ألتزم بعدم مطالبة العميل بأي مبالغ تزيد عن السعر المتفق عليه دون علم إدارة Sanay3i.",
  "ألتزم بالحفاظ على خصوصية بيانات العملاء وعدم استخدامها خارج نطاق العمل المطلوب.",
  "أقرّ بصحة البيانات الموضحة أعلاه، وأتحمّل كامل المسؤولية القانونية عن أي بيانات غير صحيحة.",
  "أوافق على سياسات وشروط العمل الخاصة بمنصّة Sanay3i، وألتزم بكود السلوك المهني الخاص بالشبكة.",
];

function PhotoBox({ src, label, hint }: { src?: string; label: string; hint: string }) {
  return (
    <div className="flex flex-col items-center gap-2">
      <div className="flex h-[130px] w-[105px] items-center justify-center overflow-hidden rounded-md border-2 border-[#003845] bg-white">
        {src ? (
          <img src={src} alt={label} className="h-full w-full object-cover" />
        ) : (
          <span className="text-xs italic text-gray-300">{hint}</span>
        )}
      </div>
      <span className="text-xs font-bold text-gray-600">{label}</span>
    </div>
  );
}

function IdBox({ src, label, hint }: { src?: string; label: string; hint: string }) {
  return (
    <div className="flex flex-1 flex-col items-center gap-2">
      <div className="flex h-[100px] w-full items-center justify-center overflow-hidden rounded-md border-2 border-gray-300 bg-white">
        {src ? (
          <img src={src} alt={label} className="h-full w-full object-contain" />
        ) : (
          <span className="text-xs italic text-gray-300">{hint}</span>
        )}
      </div>
      <span className="text-xs font-bold text-gray-600">{label}</span>
    </div>
  );
}

function FieldLine({ label, value }: { label: string; value?: string }) {
  return (
    <div className="flex items-baseline gap-2 border-b border-gray-300 pb-1">
      <span className="shrink-0 text-sm font-bold text-[#003845]">{label}</span>
      <span className="flex-1 text-sm text-gray-800">{value || "\u00A0"}</span>
    </div>
  );
}

export default function PrintApplication() {
  const [, params] = useRoute("/admin/print/:id");
  const [app, setApp] = useState<ProApplication | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!params?.id) return;
    (async () => {
      setLoading(true);
      setError("");
      try {
        const rows = await sbSelect<any>("pro_applications", { select: "*", id: `eq.${params.id}` });
        if (!rows.length) {
          setError("الطلب غير موجود.");
          return;
        }
        setApp(fromRow(rows[0]));
      } catch (err) {
        console.error(err);
        setError("مش قادر أجيب بيانات الطلب — لازم تكون مسجّل دخول كأدمن.");
      } finally {
        setLoading(false);
      }
    })();
  }, [params?.id]);

  if (loading) {
    return <div className="p-10 text-center text-gray-500">جاري التحميل...</div>;
  }
  if (error || !app) {
    return <div className="p-10 text-center text-red-600">{error || "حصلت مشكلة."}</div>;
  }

  return (
    <div dir="rtl" className="mx-auto min-h-screen max-w-3xl bg-white px-7 py-5 text-black">
      <style>{`
        @media print {
          .no-print { display: none !important; }
          @page { size: A4; margin: 12mm; }
          body { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
        }
      `}</style>

      <div className="no-print mb-6 flex justify-center">
        <Button onClick={() => window.print()} className="gap-2 bg-[#003845] hover:bg-[#0F4E5C]">
          <Printer className="h-4 w-4" />
          طباعة / حفظ PDF
        </Button>
      </div>

      {/* Header */}
      <div className="flex flex-col items-center">
        <img src={logoWordmark2x} alt="Sanay3i" className="h-10" />
        <span className="mt-1 text-xs text-gray-500">الصنايعي المضمون في إيدك</span>
      </div>
      <div className="mt-2 border-b-4 border-[#F6623D]" />
      <div className="border-b border-[#003845]" />

      <h1 className="mt-2 text-center text-2xl font-bold text-[#003845]">استمارة تسجيل صنايعي</h1>
      <p className="mt-1 text-center text-sm text-gray-500">بيانات الانضمام لشبكة صنايعية Sanay3i المعتمدين</p>

      {/* Fields + photo */}
      <div className="mt-4 flex gap-5">
        <div className="flex-1 space-y-2.5">
          <FieldLine label="الاسم بالكامل" value={app.name} />
          <FieldLine label="الرقم القومي" value={app.nationalId} />
          <FieldLine label="رقم الهاتف" value={app.phone} />
          <FieldLine label="الحرفة / التخصص" value={app.trade} />
          <FieldLine label="المدينة / المنطقة" value={app.city} />
          <FieldLine label="سنوات الخبرة" value={app.experienceYears} />
        </div>
        <PhotoBox src={app.selfieDataUrl} label="صورة شخصية" hint="4×3" />
      </div>

      {/* ID card */}
      <h2 className="mt-5 border-b-2 border-[#F6623D] pb-1 text-lg font-bold text-[#003845]">صورة البطاقة الشخصية</h2>
      <div className="mt-3 flex gap-5">
        <IdBox src={app.idFrontDataUrl} label="وش البطاقة" hint="ID — FRONT" />
        <IdBox src={app.idBackDataUrl} label="ظهر البطاقة" hint="ID — BACK" />
      </div>

      {/* Commitments */}
      <h2 className="mt-5 border-b-2 border-[#F6623D] pb-1 text-lg font-bold text-[#003845]">تعهدات الصنايعي</h2>
      <div className="mt-2 space-y-1.5">
        {COMMITMENTS.map((c, i) => (
          <div key={i} className="flex items-start gap-2 text-sm text-gray-800">
            <span className="mt-0.5 text-[#F6623D]">☐</span>
            <span>{c}</span>
          </div>
        ))}
      </div>

      {/* Signature / stamp / date */}
      <div className="mt-[18px] flex gap-4">
        <div className="flex-1 text-center">
          <div className="h-16 rounded-md border-2 border-gray-300" />
          <span className="mt-1 block text-xs font-bold text-gray-600">توقيع الصنايعي</span>
        </div>
        <div className="flex-1 text-center">
          <div className="flex h-16 items-center justify-center">
            <img src={stampOfficial} alt="Sanay3i Official Stamp" className="h-16 w-16 object-contain opacity-90" />
          </div>
          <span className="mt-1 block text-xs font-bold text-gray-600">ختم Sanay3i</span>
        </div>
        <div className="flex-1 text-center">
          <div className="flex h-16 items-center justify-center rounded-md border-2 border-gray-300 text-gray-300">
            {"  /  /"}
          </div>
          <span className="mt-1 block text-xs font-bold text-gray-600">التاريخ</span>
        </div>
      </div>

      <div className="mt-3.5 border-t pt-2 text-center text-xs italic text-gray-500">
        Sanay3i — للاستفسار والدعم: تواصل مع فريق إدارة الصنايعية
      </div>
    </div>
  );
}
