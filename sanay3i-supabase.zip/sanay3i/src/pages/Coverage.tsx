/*
  Sanay3i — Coverage Page
*/

import SiteLayout from "@/components/SiteLayout";
import PageHeader from "@/components/PageHeader";
import { MapPin, BadgeCheck } from "lucide-react";
import EgyptCoverageMap from "@/components/EgyptCoverageMap";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const CITIES = [
  "القاهرة",
  "الجيزة",
  "الإسكندرية",
  "القليوبية",
  "المنوفية",
  "الشرقية",
  "الغربية",
  "الدقهلية",
  "البحيرة",
  "الفيوم",
] as const;

export default function CoveragePage() {
  return (
    <SiteLayout>
      <PageHeader
        title="التغطية"
        subtitle="بنشتغل داخل المحافظات حسب التوفر — ابعت طلبك وهنأكد لك أقرب ميعاد."
      />
      <section className="container-sanay3i section-sanay3i pt-0">
        <div>
          <h1 className="font-display text-3xl font-bold md:text-5xl">التغطية</h1>
          <p className="mt-2 text-muted-foreground">بنشتغل داخل المحافظات حسب التوفر — ابعت طلبك وهنأكد لك أقرب ميعاد.</p>
        </div>

        <div className="mt-8 grid gap-6 md:grid-cols-12 md:items-start">
          <div className="md:col-span-5">
            <Card className="overflow-hidden card-elevated">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg flex items-center gap-2">
                  <MapPin className="h-4 w-4 text-primary" />
                  مناطق حالية/تحت الإضافة
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {CITIES.map((c) => (
                    <span key={c} className="rounded-full border bg-card px-3 py-1 text-xs text-muted-foreground">
                      {c}
                    </span>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="md:col-span-7">
            <EgyptCoverageMap />

            <Card className="mt-6 overflow-hidden card-elevated">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">ليه ده مهم؟</CardTitle>
              </CardHeader>
              <CardContent className="text-sm leading-7 text-muted-foreground">
                بدل ما تقعد تدور في كذا مكان، الطلب بيتلم في خطوة واحدة.
                وبعد كده بنسهل عليك التواصل وتأكيد الميعاد.
                <div className="mt-4 grid gap-3 sm:grid-cols-2">
                  {["تحديد خدمة + منطقة", "تأكيد قبل الزيارة", "وقت ومتابعة", "تعامل واضح"].map((x) => (
                    <div key={x} className="flex items-center gap-2 rounded-2xl border bg-card p-3">
                      <BadgeCheck className="h-4 w-4 text-primary" />
                      <div className="text-sm">{x}</div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </SiteLayout>
  );
}
