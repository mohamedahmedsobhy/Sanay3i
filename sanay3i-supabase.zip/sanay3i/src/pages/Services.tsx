/*
  Sanay3i — Services Page
*/

import SiteLayout from "@/components/SiteLayout";
import PageHeader from "@/components/PageHeader";
import { useLocation } from "wouter";
import { AlertTriangle, BadgeCheck, Bolt, Brush, Car, Droplets, Hammer, Sparkles, Wrench, ArrowLeft } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import PricingGuideDialog from "@/components/PricingGuideDialog";

const SERVICES = [
  {
    icon: Droplets,
    title: "سباكة",
    desc: "تسريب/سخان/تركيبات… مع متابعة جودة بعد الزيارة.",
    tags: ["عاجل", "تركيبات"],
  },
  {
    icon: Bolt,
    title: "كهرباء",
    desc: "أعطال/لوحات/إنارة… قياس وأمان قبل وبعد.",
    tags: ["أمان", "منازل"],
  },
  {
    icon: Brush,
    title: "دهان وتشطيب",
    desc: "دهانات داخلية وخارجية وتشطيبات سريعة بنضافة.",
    tags: ["تشطيب", "نضافة"],
  },
  {
    icon: Hammer,
    title: "نجارة",
    desc: "إصلاح/تركيب مطابخ/أبواب… شغل مضبوط.",
    tags: ["تركيب", "إصلاح"],
  },
  {
    icon: Wrench,
    title: "تكييف وصيانة",
    desc: "تنظيف/تركيب/شحن… مع فحص قبل التنفيذ.",
    tags: ["صيانة", "صيف"],
  },
  {
    icon: Sparkles,
    title: "تنضيف عميق",
    desc: "شقق/مكاتب… فرق مواعيد واضحة ونتيجة ملموسة.",
    tags: ["مواعيد", "فرق"],
  },
  {
    icon: Wrench,
    title: "إصلاح أجهزة كهربائية",
    desc: "غسالات/ثلاجات/سخانات… تشخيص واضح قبل الإصلاح.",
    tags: ["تشخيص", "قطع غيار"],
  },
  {
    icon: Car,
    title: "صيانة سيارات",
    desc: "كشف/إصلاح… يا إما نجيلك مكان العربية أو نستلمها ونسلمها بعد الشغل.",
    tags: ["زيارة", "استلام"],
  },
  {
    icon: AlertTriangle,
    title: "طوارئ",
    desc: "ماس كهربائي/عطل في الطريق/ماسورة اتكسرت… استجابة سريعة قدر الإمكان.",
    tags: ["سريع", "طارئ"],
  },
] as const;

export default function ServicesPage() {
  const [, setLocation] = useLocation();

  return (
    <SiteLayout>
      <PageHeader
        title="الخدمات"
        subtitle="اختار الخدمة اللي محتاجها… وسيب الباقي علينا."
        right={
          <div className="flex items-center gap-3">
            <div className="hidden md:flex items-center gap-2 rounded-full border bg-card px-3 py-1 text-xs text-muted-foreground shadow-sm">
              <BadgeCheck className="h-4 w-4 text-primary" />
              تأكيد قبل التنفيذ + متابعة جودة
            </div>
            <PricingGuideDialog />
          </div>
        }
      />
      <section className="container-sanay3i section-sanay3i pt-0">
        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {SERVICES.map((s) => (
            <Card key={s.title} className="group overflow-hidden min-h-[176px] card-elevated">
              <CardHeader className="pb-2">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="grid h-11 w-11 place-items-center rounded-2xl bg-secondary text-secondary-foreground">
                      <s.icon className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <CardTitle className="text-lg">{s.title}</CardTitle>
                      <div className="text-xs text-muted-foreground">طلبات سريعة + تأكيد</div>
                    </div>
                  </div>
                  <div className="flex gap-1">
                    {s.tags.map((t) => (
                      <span key={t} className="rounded-full bg-primary/10 px-2 py-1 text-[11px] text-primary">
                        {t}
                      </span>
                    ))}
                  </div>
                </div>
              </CardHeader>
              <CardContent className="pt-0">
                <p className="text-sm leading-6 text-muted-foreground">{s.desc}</p>
                <div className="mt-4">
                  <Button 
                    className="w-full gap-2" 
                    onClick={() => setLocation(`/booking?service=${encodeURIComponent(s.title)}`)}
                  >
                    <span>احجز {s.title}</span>
                    <ArrowLeft className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>
    </SiteLayout>
  );
}
