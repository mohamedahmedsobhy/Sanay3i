/*
  Sanay3i — PageHeader
  Consistent title + subtitle block for all pages.
*/

import type { ReactNode } from "react";

export default function PageHeader({
  title,
  subtitle,
  right,
}: {
  title: string;
  subtitle?: string;
  right?: ReactNode;
}) {
  return (
    <div className="page-hero">
      <div className="container-sanay3i section-sanay3i pt-10 md:pt-12 relative">
        <div className="grid gap-4 md:grid-cols-12 md:items-end">
          <div className="md:col-span-8">
            <h1 className="font-display text-3xl font-bold leading-tight md:text-5xl">
              {title}
            </h1>
            {subtitle ? (
              <p className="mt-2 max-w-2xl text-muted-foreground leading-7">{subtitle}</p>
            ) : null}
          </div>
          {right ? <div className="md:col-span-4 md:justify-self-end">{right}</div> : null}
        </div>
      </div>
    </div>
  );
}
