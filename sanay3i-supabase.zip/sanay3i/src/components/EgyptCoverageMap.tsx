/*
  EgyptCoverageMap
  - Uses a web-optimized SVG map of Egypt (admin regions)
  - Covered governorates are highlighted
  Source SVG: MapSVG (CC BY 4.0)
*/

import { useMemo } from "react";
import egyptSvgRaw from "@/assets/egypt.svg?raw";

const COVERED_IDS = new Set([
  "EG-C", // Cairo
  "EG-GZ", // Giza
  "EG-ALX", // Alexandria
  "EG-KB", // Qalyubiyah
  "EG-DK", // Dakahlia
  "EG-GH", // Gharbia
  "EG-SHR", // Sharqiyah
  "EG-MNF", // Monufia
  "EG-BH", // Beheira
  "EG-FYM", // Fayoum
]);

function normalizeSvg(svgText: string) {
  const parser = new DOMParser();
  const doc = parser.parseFromString(svgText, "image/svg+xml");
  const svg = doc.querySelector("svg");
  if (!svg) return svgText;

  // Ensure responsive sizing
  const w = svg.getAttribute("width");
  const h = svg.getAttribute("height");
  if (!svg.getAttribute("viewBox") && w && h) {
    const width = parseFloat(w);
    const height = parseFloat(h);
    if (Number.isFinite(width) && Number.isFinite(height)) {
      svg.setAttribute("viewBox", `0 0 ${width} ${height}`);
    }
  }
  svg.removeAttribute("width");
  svg.removeAttribute("height");

  svg.setAttribute("class", "egypt-map");
  svg.setAttribute("role", "img");
  svg.setAttribute("aria-label", "خريطة مصر");

  // Mark covered regions
  svg.querySelectorAll("path[id]").forEach((p) => {
    const id = p.getAttribute("id") || "";
    if (COVERED_IDS.has(id)) p.setAttribute("data-covered", "true");
  });

  // Remove external namespaces that aren't needed
  svg.removeAttribute("xmlns:mapsvg");

  return svg.outerHTML;
}

export default function EgyptCoverageMap() {
  const svg = useMemo(() => normalizeSvg(egyptSvgRaw), []);

  return (
    <div className="relative overflow-hidden rounded-3xl border bg-card p-4 md:p-6 card-elevated">
      <div className="flex items-center justify-between gap-3">
        <div>
          <div className="font-display text-lg font-bold">التغطية على الخريطة</div>
          <div className="mt-1 text-sm text-muted-foreground">المناطق المظللة هي المحافظات المتاحة حاليًا.</div>
        </div>
      </div>

      <div className="mt-5 egypt-map-wrap">
        <div className="egypt-map-inner" dangerouslySetInnerHTML={{ __html: svg }} />
      </div>

      <div className="mt-4 flex flex-wrap gap-2 text-xs">
        <span className="inline-flex items-center gap-2 rounded-full border bg-secondary/60 px-3 py-1 text-muted-foreground">
          <span className="h-2.5 w-2.5 rounded-full bg-primary" />
          متاح الآن
        </span>
        <span className="inline-flex items-center gap-2 rounded-full border bg-secondary/60 px-3 py-1 text-muted-foreground">
          <span className="h-2.5 w-2.5 rounded-full bg-muted-foreground/25" />
          قريبًا
        </span>
        <span className="text-muted-foreground">تلميح: مرّر على الخريطة لعرض اسم المحافظة.</span>
      </div>
    </div>
  );
}
