/*
  Sanay3i — FloatingNav
  - Telegram-style floating menu for navigation
  - Works with hash-router (#/path)
*/

import { useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Compass,
  Layers,
  MapPinned,
  CalendarCheck,
  HelpCircle,
  Users,
  Search,
  Shield,
  Wrench,
  Menu,
  X,
} from "lucide-react";

import { cn } from "@/lib/utils";

type NavItem = {
  label: string;
  href: string;
  icon: any;
  tone?: "primary" | "accent";
};

export default function FloatingNav() {
  const [open, setOpen] = useState(false);

  const items = useMemo<NavItem[]>(
    () => [
      { label: "الرئيسية", href: "#/", icon: Compass, tone: "primary" },
      { label: "الخدمات", href: "#/services", icon: Layers },
      { label: "ازاي بنشتغل", href: "#/how", icon: Wrench },
      { label: "التغطية", href: "#/coverage", icon: MapPinned },
      { label: "احجز", href: "#/booking", icon: CalendarCheck, tone: "accent" },
      { label: "متابعة الطلب", href: "#/track", icon: Search },

      { label: "الأسئلة", href: "#/faq", icon: HelpCircle },
      { label: "بوابة الصنايعي", href: "#/pro/register", icon: Wrench },
      { label: "دخول الصنايعي", href: "#/pro/login", icon: Wrench },
      { label: "لوحة الصنايعي", href: "#/pro/dashboard", icon: Wrench },
      { label: "داشبورد الإدارة", href: "#/admin", icon: Shield },
    ],
    []
  );

  return (
    <div className="fixed bottom-5 right-5 z-50">
      <div className="relative">
        <AnimatePresence>
          {open ? (
            <motion.div
              initial={{ opacity: 0, y: 12, scale: 0.98 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 12, scale: 0.98 }}
              transition={{ duration: 0.18, ease: "easeOut" }}
              className="absolute bottom-16 right-0 w-[16.5rem] overflow-hidden rounded-3xl border bg-card/95 backdrop-blur shadow-[0_22px_60px_-45px_rgba(0,0,0,.45)]"
            >
              <div className="px-4 pt-4 pb-2">
                <div className="font-display text-sm font-bold">التنقل السريع</div>
                <div className="mt-1 text-xs text-muted-foreground">اختار صفحة وكمّل.</div>
              </div>

              <div className="px-2 pb-3 max-h-[50vh] overflow-y-auto overscroll-contain">
                {items.map((it, idx) => (
                  <motion.a
                    key={it.href}
                    href={it.href}
                    onClick={() => setOpen(false)}
                    initial={{ opacity: 0, x: 10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.03 * idx, duration: 0.16 }}
                    className={cn(
                      "flex items-center gap-3 rounded-2xl px-3 py-2.5 text-sm transition-colors",
                      "hover:bg-secondary/70",
                      it.tone === "primary" && "text-primary",
                      it.tone === "accent" && "text-accent-foreground"
                    )}
                  >
                    <span
                      className={cn(
                        "grid h-9 w-9 place-items-center rounded-2xl border bg-background",
                        it.tone === "primary" && "border-primary/20 bg-primary/5",
                        it.tone === "accent" && "border-accent/25 bg-accent/10"
                      )}
                    >
                      <it.icon className={cn("h-4 w-4", it.tone === "accent" ? "text-accent" : "text-primary")} />
                    </span>
                    <span className="flex-1">{it.label}</span>
                  </motion.a>
                ))}
              </div>
            </motion.div>
          ) : null}
        </AnimatePresence>

        <button
          type="button"
          aria-label={open ? "إغلاق القائمة" : "فتح القائمة"}
          onClick={() => setOpen((v) => !v)}
          className={cn(
            "group grid h-14 w-14 place-items-center rounded-full border bg-primary text-primary-foreground shadow-lg",
            "transition-transform hover:-translate-y-0.5 active:translate-y-0"
          )}
        >
          {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </div>
    </div>
  );
}
