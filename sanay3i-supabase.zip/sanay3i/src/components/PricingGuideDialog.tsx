import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Info } from "lucide-react";

export default function PricingGuideDialog() {
  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="outline" className="gap-2">
          <Info className="h-4 w-4" />
          دليل الأسعار التقريبي
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="font-display text-2xl">متوسط أسعار الخدمات</DialogTitle>
        </DialogHeader>
        <div className="mt-4 space-y-4 text-sm">
          <p className="text-muted-foreground">
            الأسعار دي تقريبية وبتختلف حسب حجم الشغل وتفاصيله. الصنايعي هيأكد السعر النهائي بعد المعاينة أو التشخيص.
          </p>
          
          <div className="grid gap-2 border rounded-lg p-4 bg-secondary/10">
            <div className="grid grid-cols-2 font-bold border-b pb-2 mb-2">
              <div>الخدمة</div>
              <div>متوسط السعر (جنيه)</div>
            </div>
            {[
              { name: "زيارة كشف / معاينة", price: "100 - 150" },
              { name: "صيانة سباكة بسيطة (تسريب/خلاط)", price: "200 - 400" },
              { name: "صيانة كهرباء (تغيير مفاتيح/أعطال)", price: "200 - 500" },
              { name: "تنظيف تكييف (للوحدة)", price: "350 - 500" },
              { name: "شحن فريون تكييف", price: "600 - 900" },
              { name: "نجارة (تركيب كالون/إصلاح باب)", price: "150 - 300" },
              { name: "تنظيف عميق (للغرفة)", price: "300 - 500" },
              { name: "كشف سيارة (كمبيوتر)", price: "200 - 350" },
            ].map((item, idx) => (
              <div key={idx} className="grid grid-cols-2 py-1 text-muted-foreground">
                <div>{item.name}</div>
                <div className="font-medium text-foreground">{item.price} ج.م</div>
              </div>
            ))}
          </div>

          <div className="rounded-lg bg-yellow-500/10 p-3 text-yellow-600 text-xs">
            * السعر لا يشمل قطع الغيار.
            <br />
            * في حالة تنفيذ الشغل، بيتم خصم قيمة المعاينة من الإجمالي (حسب الاتفاق).
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
