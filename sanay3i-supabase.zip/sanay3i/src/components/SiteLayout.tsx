/*
  Sanay3i — SiteLayout (Multi-page)
  - Clean header + floating Telegram-style nav
  - WhatsApp stays for inquiries
*/

import { useMemo } from "react";
import type { ReactNode } from "react";

import logoWordmark from "@/assets/logo-wordmark-tight.png";
import logoWordmark2x from "@/assets/logo-wordmark-tight-2x.png";

import FloatingNav from "@/components/FloatingNav";
import { Button } from "@/components/ui/button";
import WhatsAppFab from "@/components/WhatsAppFab";


const WHATSAPP_BUSINESS_NUMBER = "201270084490";

export default function SiteLayout({ children }: { children: ReactNode }) {
  const waChatUrl = useMemo(() => {
    const msg = "مرحبًا، عايز استفسر عن خدمة/حجز.";
    return `https://wa.me/${WHATSAPP_BUSINESS_NUMBER}?text=${encodeURIComponent(msg)}`;
  }, []);

  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="sticky top-0 z-50 border-b bg-background/80 backdrop-blur supports-[backdrop-filter]:bg-background/65">
        <div className="container-sanay3i">
          <div className="flex h-16 items-center justify-between gap-3">
            <a href="#/" className="flex items-center gap-3">
              <div className="leading-tight select-none">
                <img
                  src={logoWordmark}
                  srcSet={`${logoWordmark2x} 2x`}
                  alt="Sanay3i"
                  className="h-8 w-auto md:h-9"
                  loading="eager"
                />
                <div className="text-[11px] text-muted-foreground">الصنايعي المضمون في إيدك</div>
              </div>
            </a>

            <div className="flex items-center gap-2">
              <a href={waChatUrl} target="_blank" rel="noreferrer">
                <Button className="bg-accent text-accent-foreground hover:bg-accent/90">واتساب للاستفسار</Button>
              </a>
            </div>
          </div>
        </div>
      </header>

      <main className="pb-16">{children}</main>

      {/* Telegram-style navigation */}
      <FloatingNav />
      <WhatsAppFab />
    </div>
  );
}
