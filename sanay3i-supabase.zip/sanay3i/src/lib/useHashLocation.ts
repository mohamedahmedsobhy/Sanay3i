import { useState, useEffect } from "react";
import type { BaseLocationHook } from "wouter";

// returns the current hash location (minus the '#' symbol)
// strips query params for routing purposes
const currentLocation = () => {
  const hash = window.location.hash.replace(/^#/, "") || "/";
  // If the hash contains a query string, we want to strip it for routing purposes
  // The query string can still be accessed via window.location.hash inside components.
  const path = hash.split("?")[0];
  // Ensure we always return at least "/" if empty
  return path || "/";
};

export const useHashLocation: BaseLocationHook = () => {
  const [loc, setLoc] = useState(currentLocation());

  useEffect(() => {
    const handler = () => setLoc(currentLocation());

    // Subscribe to hash changes
    window.addEventListener("hashchange", handler);
    return () => window.removeEventListener("hashchange", handler);
  }, []);

  const navigate = (to: string) => {
    window.location.hash = to;
  };

  return [loc, navigate];
};
