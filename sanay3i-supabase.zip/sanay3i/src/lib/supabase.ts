/*
  Sanay3i — Supabase data layer
  - Talks to the Supabase REST API (PostgREST) and Auth API (GoTrue)
    directly via axios, so no extra npm package (@supabase/supabase-js)
    is required.
  - Replaces the old localStorage-only persistence with a real shared
    Postgres database: every visitor/device sees the same data.
  - Admin login uses real Supabase Auth (email/password). Everything
    else (booking, tracking, pro login/dashboard) goes through
    SECURITY DEFINER RPC functions so the underlying tables can stay
    locked down to admins only — see the "secure_rls_and_public_rpcs"
    migration for the server side of this.
*/

import axios from "axios";

// Public project values — safe to ship in client code (protected by RLS policies)
export const SUPABASE_URL = "https://ukvcnnywwstcihrmanct.supabase.co";
export const SUPABASE_ANON_KEY =
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InVrdmNubnl3d3N0Y2locm1hbmN0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODg4OTUzOTAsImV4cCI6MjEwNDQ3MTM5MH0.deXQNbA1bf8ZnGCK3v6rchteAqCRlx8xCODUwUcmil8";

const ADMIN_SESSION_KEY = "sanay3i_admin_session";

// ---------------------------------------------------------------------------
// Admin session (real Supabase Auth)
// ---------------------------------------------------------------------------

export type AdminSession = {
  access_token: string;
  refresh_token: string;
  expires_at: number; // epoch seconds
  email: string;
};

export function getAdminSession(): AdminSession | null {
  try {
    const raw = localStorage.getItem(ADMIN_SESSION_KEY);
    if (!raw) return null;
    return JSON.parse(raw) as AdminSession;
  } catch {
    return null;
  }
}

export function isAdminSessionValid(): boolean {
  const s = getAdminSession();
  if (!s) return false;
  return s.expires_at * 1000 > Date.now();
}

export function clearAdminSession() {
  localStorage.removeItem(ADMIN_SESSION_KEY);
}

/** Sign in against real Supabase Auth (email + password). Throws on failure. */
export async function adminSignIn(email: string, password: string): Promise<AdminSession> {
  const { data } = await axios.post(
    `${SUPABASE_URL}/auth/v1/token`,
    { email, password },
    {
      params: { grant_type: "password" },
      headers: { apikey: SUPABASE_ANON_KEY, "Content-Type": "application/json" },
    }
  );
  const session: AdminSession = {
    access_token: data.access_token,
    refresh_token: data.refresh_token,
    expires_at: Math.floor(Date.now() / 1000) + Number(data.expires_in || 3600),
    email: data.user?.email || email,
  };
  localStorage.setItem(ADMIN_SESSION_KEY, JSON.stringify(session));
  return session;
}

export async function adminSignOut() {
  const s = getAdminSession();
  clearAdminSession();
  if (!s) return;
  try {
    await axios.post(`${SUPABASE_URL}/auth/v1/logout`, {}, {
      headers: { apikey: SUPABASE_ANON_KEY, Authorization: `Bearer ${s.access_token}` },
    });
  } catch {
    // ignore — session is cleared locally regardless
  }
}

// ---------------------------------------------------------------------------
// PostgREST data layer
// ---------------------------------------------------------------------------

const rest = axios.create({
  baseURL: `${SUPABASE_URL}/rest/v1`,
  headers: { apikey: SUPABASE_ANON_KEY, "Content-Type": "application/json" },
});

// Use the admin's access token (real, authenticated role) when a valid
// session exists; otherwise fall back to the public anon key.
rest.interceptors.request.use((config) => {
  const s = isAdminSessionValid() ? getAdminSession() : null;
  config.headers = config.headers || {};
  (config.headers as any).Authorization = `Bearer ${s ? s.access_token : SUPABASE_ANON_KEY}`;
  return config;
});

export type Query = Record<string, string | number | undefined>;

function toParams(query?: Query) {
  const params: Record<string, string> = {};
  if (query) {
    for (const [k, v] of Object.entries(query)) {
      if (v !== undefined) params[k] = String(v);
    }
  }
  return params;
}

/** SELECT rows from a table (admin/authenticated tables only — see RLS). */
export async function sbSelect<T = any>(table: string, query?: Query): Promise<T[]> {
  const { data } = await rest.get(`/${table}`, { params: toParams(query) });
  return data as T[];
}

/** INSERT one row and return it. */
export async function sbInsert<T = any>(table: string, row: Record<string, any>): Promise<T> {
  const { data } = await rest.post(`/${table}`, row, {
    headers: { Prefer: "return=representation" },
  });
  return (Array.isArray(data) ? data[0] : data) as T;
}

/** UPDATE rows matching the filter and return them. */
export async function sbUpdate<T = any>(
  table: string,
  filter: Query,
  patch: Record<string, any>
): Promise<T[]> {
  const { data } = await rest.patch(`/${table}`, patch, {
    params: toParams(filter),
    headers: { Prefer: "return=representation" },
  });
  return data as T[];
}

/** UPSERT one row (insert or update on conflict) and return it. */
export async function sbUpsert<T = any>(
  table: string,
  row: Record<string, any>,
  onConflict: string
): Promise<T> {
  const { data } = await rest.post(`/${table}`, row, {
    params: { on_conflict: onConflict },
    headers: { Prefer: "resolution=merge-duplicates,return=representation" },
  });
  return (Array.isArray(data) ? data[0] : data) as T;
}

/** DELETE rows matching the filter. */
export async function sbDelete(table: string, filter: Query): Promise<void> {
  await rest.delete(`/${table}`, { params: toParams(filter) });
}

/** Call a Postgres RPC function (works for anon-callable public functions too). */
export async function sbRpc<T = any>(fn: string, args?: Record<string, any>): Promise<T> {
  const { data } = await rest.post(`/rpc/${fn}`, args || {});
  return data as T;
}
