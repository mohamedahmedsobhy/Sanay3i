import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Router, Route, Switch } from "wouter";
import { useHashLocation } from "@/lib/useHashLocation";
import ErrorBoundary from "@/components/ErrorBoundary";
import { ThemeProvider } from "@/contexts/ThemeContext";
import { Button } from "@/components/ui/button";
import Home from "@/pages/Home";
import ServicesPage from "@/pages/Services";
import HowPage from "@/pages/How";
import CoveragePage from "@/pages/Coverage";
import BookingPage from "@/pages/Booking";
import TeamPage from "@/pages/Team";
import FaqPage from "@/pages/Faq";

import ProRegister from "@/pages/ProRegister";
import ProLogin from "@/pages/ProLogin";
import ProDashboard from "@/pages/ProDashboard";
import TrackRequest from "@/pages/TrackRequest";
import AdminLogin from "@/pages/AdminLogin";
import AdminDashboard from "@/pages/AdminDashboard";
import PrintApplication from "@/pages/PrintApplication";
import PrintInvoice from "@/pages/PrintInvoice";


// Use hash-based routing (/#/) to support opening index.html directly via file:// protocol
// Tolerant routing: unmatched paths are treated as anchor sections (e.g., /#/services → scroll to #services)
// For in-page anchors, use <Link href="/section"> instead of <a href="#section">
function AppRouter() {
  return (
    <Router hook={useHashLocation}>
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/services" component={ServicesPage} />
        <Route path="/how" component={HowPage} />
        <Route path="/coverage" component={CoveragePage} />
        <Route path="/booking" component={BookingPage} />
        <Route path="/team" component={TeamPage} />
        <Route path="/faq" component={FaqPage} />

        <Route path="/pro/register" component={ProRegister} />
        <Route path="/pro/login" component={ProLogin} />
        <Route path="/pro/dashboard" component={ProDashboard} />
        <Route path="/track" component={TrackRequest} />
        <Route path="/admin" component={AdminLogin} />
        <Route path="/admin/dashboard" component={AdminDashboard} />
        <Route path="/admin/print/:id" component={PrintApplication} />
        <Route path="/invoice/:code" component={PrintInvoice} />

        {/* Fallback to Home if route not found */}
        <Route>
          <div className="flex min-h-[80vh] flex-col items-center justify-center p-10 text-center">
            <h1 className="font-display text-6xl font-bold text-primary">404</h1>
            <p className="mt-4 text-muted-foreground text-lg">الصفحة دي مش موجودة أو لسه تحت الصيانة.</p>
            <a href="#/" className="mt-8">
              <Button size="lg">ارجع للرئيسية</Button>
            </a>
          </div>
        </Route>
      </Switch>
    </Router>
  );
}

// Note on theming:
// - Choose defaultTheme based on your design (light or dark background)
// - Update the color palette in index.css to match
// - If you want switchable themes, add `switchable` prop and use `useTheme` hook

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light" switchable>
        <TooltipProvider>
          <Toaster />
          <AppRouter />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;

