# Sanay3i × Supabase — إيه اللي اتعمل

## المشروع
- تم ربط المشروع بمشروع Supabase حقيقي وشغال:
  - **Project ref:** `ukvcnnywwstcihrmanct`
  - **URL:** `https://ukvcnnywwstcihrmanct.supabase.co`
  - فيه Schema كامل: `bookings`, `pros`, `pro_applications`, `ratings`,
    `booking_status_history`, `notifications`, `services`, `profiles`.
  - RLS شغالة على كل الجداول بصلاحيات عامة (public) تسمح بالقراءة/الكتابة
    من الموقع عن طريق الـ anon key — تمامًا زي مستوى الحماية اللي كان
    موجود أصلاً في نسخة localStorage (تسجيل الدخول للإدارة/الصنايعي لسه
    عبارة عن بوابة على مستوى المتصفح فقط، مش Supabase Auth حقيقي).

## اللي اتغيّر في الكود
- ملف جديد: `src/lib/supabase.ts` — بيكلم Supabase عن طريق `axios`
  (موجودة أصلاً في `package.json`)، من غير أي مكتبة جديدة.
- الصفحات دي بقت بتقرا/تكتب في قاعدة البيانات بدل `localStorage`:
  - `Booking.tsx` — إرسال طلب الحجز
  - `TrackRequest.tsx` — البحث/التعديل/الإلغاء/التقييم
  - `ProRegister.tsx` — تسجيل الصنايعي
  - `ProLogin.tsx` — دخول الصنايعي بالكود
  - `ProDashboard.tsx` — طلبات الصنايعي وتحديث حالتها
  - `AdminDashboard.tsx` — كل عمليات الإدارة (قبول/رفض، تعيين صنايعي، تحديث الحالة)
- علامات تسجيل الدخول (`sanay3i_admin_authed`, `sanay3i_pro_authed*`) لسه
  في `localStorage` لأنها حالة جلسة على الجهاز بس، مش بيانات مشتركة.

## ⚠️ حاجة مهمة لازم تعرفها
البيئة اللي شغال فيها الشات دي **مقفولة تمامًا من الإنترنت** (مفيش أي
اتصال بالـ npm registry)، فمش قادر أعمل `npm install` أو `npm run build`
هنا، وبالتالي **مش هقدر أطلعلك ملف `dist` جاهز** — ده قيد فعلي في
السيرفر بتاعي، مش اختيار.

## إزاي تاخد ملف `dist` من غير ما "تتكلم مع npm"
أسهل طريقة: ارفع الكود على **Vercel** أو **Netlify** — المنصة نفسها
هي اللي هتعمل build (بالإنترنت اللي عندها)، وانت هتاخد رابط الموقع
شغال من غير ما تكتب أي أمر:

1. روح على vercel.com أو netlify.com واعمل حساب (لو معندكش).
2. اختار "Import project" وارفع مجلد الكود ده (أو اربطه بـ GitHub).
3. Build command: `npm run build` — Output directory: `dist`
   (المنصة بتكتشفهم أوتوماتيك عادةً لأنه مشروع Vite).
4. اضغط Deploy — وخلاص، هتاخد رابط شغال ومعاه ملف `dist` جاهز لو حبيت
   تنزّله من إعدادات الـ build.

لو حبيت تعمل build بنفسك على جهازك (لما يبقى معاك إنترنت وجهاز فيه Node):
```
npm install
npm run build
```
وهتلاقي المخرجات في مجلد `dist/`.

## تحديث: تسجيل دخول الإدارة بقى Auth حقيقي 🔐
- محدش بقى شايف الباسورد في الكود. تسجيل دخول الإدارة بقى عن طريق
  **Supabase Auth** حقيقي (جدول `auth.users`)، مش check في المتصفح.
- بيانات الدخول:
  - **الإيميل:** `sanay3i.fixit@gmail.com`
  - **الباسورد:** `Sanay3i@2026`
  - (تقدر تغيّرهم بعدين من Supabase Dashboard → Authentication → Users)
- الجلسة (access token) بتتخزن في `localStorage` وصالحة لمدة ساعة تقريبًا؛
  بعدها المستخدم يسجل دخول تاني.

## تحديث: تأمين البيانات الحساسة
كانت فيه ثغرة مهمة: كل الجداول كانت قابلة للقراءة من أي حد عنده الـ
anon key (زي الصور وأرقام البطاقات الشخصية لطلبات الانضمام، وكل الحجوزات،
وأكواد دخول الصنايعية). اتعمل الآتي:
- كل الجداول (`bookings`, `pro_applications`, `pros`, `ratings`, ...)
  بقت **SELECT/UPDATE للإدارة (authenticated) بس**.
- العمليات العامة (حجز، تتبع الطلب، تسجيل/دخول الصنايعي، تحديث حالة
  الطلب من الصنايعي) بقت بتعدي من خلال **RPC functions** آمنة
  (`track_booking`, `reschedule_booking`, `cancel_booking`, `pro_login`,
  `pro_dashboard`, `pro_update_booking_status`) بترجع بس البيانات
  المطلوبة، من غير ما تكشف باقي الجداول.

## الموقع شغال من أي جهاز
بما إن كل البيانات بقت على Supabase (مش localStorage)، الموقع بيشتغل
بنفس الشكل من أي متصفح أو جهاز — مفيش بيانات محبوسة جوه جهاز واحد.
تصميم الصفحات أصلاً متجاوب (Tailwind breakpoints: `sm/md/lg`) وبيشتغل
كويس على الموبايل والتابلت والديسكتوب.
